<?php
include 'dbconfig/config.php';
$query = "select * from event";
$result = $con->query($query) or die($con->error);
$eventResult = array();
while ($row =$result->fetch_assoc()) {
    $eventResult[] = $row;
}
echo json_encode($eventResult);
?>
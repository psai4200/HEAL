

<?php
require 'dbconfig/config.php';
require 'vendor/autoload.php';
define("PROJECT_NAME", "http://localhost/finaloffinal/");
$mail = new PHPMailer\PHPMailer\PHPMailer;
//Enable SMTP debug mode
$mail->SMTPDebug = 0;
//set PHPMailer to use SMTP
$mail->isSMTP();
//set host name
$mail->Host = "smtp.gmail.com";
// set this true if SMTP host requires authentication to send mail
$mail->SMTPAuth = true;
//Provide username & password
$mail->Username = "dancerdivya79@gmail.com";
$mail->Password = "12divya34kavya";
$mail->SMTPSecure = "tls";
$mail->Port = 587;

$mail->From = "dhathwar91@gmail.com";
$mail->FromName = "Divya P Hathwar";
$mail->addAddress($_POST["user-email"]);
$mail->isHTML(true);

$mail->Subject = "Forget Password Recovery";
$mail->Body="<div>".$user[0]["dname"]."<br><br><p>Click here to recover your password<br>
    <a href='".PROJECT_NAME."resetPassword.php?dname=".$user[0]["dname"]."'> ".PROJECT_NAME.
        "resetPassword.php?dname=".$user[0]["dname"]."</a><br><br></p>Regards<br> Admin.</div>";

        if(!$mail->send()) {
            $error_message = "Mailer Error : ". $mail->ErrorInfo;
        } else {
            $success_message = "Message has been sent successfully";
        }
        

      ?> 

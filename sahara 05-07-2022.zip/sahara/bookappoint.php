<?php
ini_set( "display_errors", 0); 
ob_start();
	require 'dbconfig/config.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title>Sahara | Book Appoitments </title>
<link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat+Alternates" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans+JP:300,400,500" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700" rel="stylesheet">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">



<style>
	 #login-block{    
		padding: 10px 45px 20px 45px;
		border-radius: 5px;
		border: solid 1px #000000;
		background-color: #ffffff;
	}
	.myform{
		width: 100%;
	}
	.label-text{
        font-family: 'Raleway';
        font-size: 22px;
        font-weight: 400;
        text-align: left;
    }
    .input-text{
		margin-left: 10px;
		width: 30%;
		position: relative;
		bottom: 3px;
		margin-right: 20px;
	}
    #signup_btn{
		text-align: center;
		border-radius: 25px;
		border: solid 0 #000000;
		background-color: #5796e0;
		width: 50%;
		position: relative;
		margin-top: 20px;
		font-family: 'Raleway';
		font-weight: 400;
		font-size: 24px;
        color: white;
		text-transform: uppercase;
	}
	.inputvalues{
		width: 30%;
		position: relative;
		bottom: 3px;
		margin-left: 10px;
	}
	.heading{
		text-align: center;
		font-size: 24px;
		font-family: 'Raleway';
		text-transform: uppercase;
		margin-top: 10px;
		margin-bottom: 35px;
	}
	.avatar{
		width: 12%;
		margin-top: 5px;
    	margin-bottom: 10px;
	}
	.nav-style{
		list-style-type: none !important;
		border-radius: 20px;
		background-color: #ffffff;
		padding: 10px 30px 10px 30px !important;
		border: solid 2px #92cdd5;
		margin-right: 10px;
		font-family: 'Raleway';
		font-size: 18px;
		letter-spacing: 1px;
	}

	.dropdown-item{
		padding: 0px 10px;
    	font-size: 18px;
	}
	.dropdown-menu{
		padding: 15px;
		width: 250px;
		border-radius: 10px;
		box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
		background: #fff;
	}
	.sidenav {
          background: #92cdd5;
          text-align: center;
          color: black;
          position: fixed;
          left: 0;
          top: 0;
          width: 15%;
          min-height: calc(100vh - 0px);
          overflow: auto;
        }
        
        .sidenav a {
          /* padding: 20px 6px 25px 32px; */
          text-decoration: none;
          font-size: 20px;
          color: #000;
          display: block;
          text-align: left;
          margin-left: 20px;
          margin-top: 35px;
          font-family: 'Raleway';
        }
        
        .sidenav a:hover {
          color: #f1f1f1;
        }
</style>
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-expand-lg navbar-light" style="background-image: linear-gradient( to left,#92cdd5, #ffffff, #ffffff);">
        <a class="navbar-brand" href="#">
            <img class="" src="imgs/SaharaLogo.png" alt="sahara-logo" style="width: 60%;">
        </a>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="indexmain.php">Home</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="aboutmain.php">About</a>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            Login
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
		  	<a class="dropdown-item" href="logincare.php">Caretaker</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logindoc.php">Doctor</a>
          </div>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Register
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">

              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registercare.php">Caretaker</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registerdoc.php">Doctor</a>
            </div>
          </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link" href="helpmain.php">Contact Us</a>
          </li>
      </ul>
    </div>
      </nav>
<!------------------------------------------------------------------------------------------------------------------>
<!---------------------------------------------------------------------------------------------------------->
<div class="sidenav">
    <h4 style="margin-top: 55%;"></h4>
    <a href="homepagecare.php">Home</a>
    <a href="doctor-page.php">Doctors</a>
    <a href="homepagepatient.php">Patients</a>
    <a href="departments.php">Department</a>
    <a href="registerpatient.php">Patient Registration</a>
    <?php
	$stmt = $db->prepare('SELECT cid, cname, area, gender, image, address, username, email, password FROM userscare ORDER BY cid DESC');
	$stmt->execute();
if($stmt->rowCount() > 0)
{
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		extract($row);
		?>
      <a href="aboutcare.php">About</a>
      <a href="helpcare.php">Help</a>
		</div>       
		<?php
	}
}
else
{
	?> 
	<div class="col-xs-12">
		<div class="alert alert-warning">
			<span class="glyphicon glyphicon-info-sign"></span>&nbsp; No Data Found.
		</div>
	</div>
	<?php
}
?>
<!------------------------------------------------------------------------------>
	  <!-- BODY CONTENT -->
	  <div class="container" style="    margin-top: 180px;">
		<div class="row" style="margin-left: 200px;">
			<h2 class="heading" style="margin-bottom: 0;">Book Appointment</h2>
			<a class="btn btn-success" href="homepagecare.php" style="position: relative; bottom: 40px;left: 92%;"><span class="glyphicon glyphicon-home"></span>&nbsp; Back</a>
		
	<div class="col-md-12" id="login-block">		
	<form class="myform" action="bookappoint.php"method="post" enctype="multipart/form-data" >
	<label class="label-text">
				Patient ID:
			</label>
			<input type="text" name="pid" placeholder="Enter your pid" class="input-text" required> 
			<label class="label-text">
				Doctor Name: 
			</label>
			<input type="text" name="dname" placeholder="Enter doctor's name" class="input-text" style="margin-right: 40px;"required> 
			<label for="spec" class="label-text">
			Speciality:
		</label>
		<!-- <input name="spec" type="text" class="inputvalues" placeholder="Your speciality" class="input-text"required/><br> -->
		<select id="spec" class="inputvalues" name="spec" style="width: 30%;position: relative;bottom: 3px;">
				<option value="general">General Medicine</option>
				<option value="pregnancy">Pregnancy</option>
				<option value="surgery">Surgery</option>
				<option value="neuro">Neurology</option>
				<option value="pediatrics">Pediatrics</option>
				<option value="psycho">Psychology</option>
			</select>
			<label class="label-text" style="margin-left:28px">
				Patient name:
			</label>
			<input name="pname" type="text" class="inputvalues" placeholder="Enter your name" class="input-text" required/><br>
			<br>
			<label class="label-text" style="margin-left:28px">
				Caretaker name:
			</label>
			<input name="cname" type="text" class="inputvalues" placeholder="Enter your name" class="input-text" required/><br>
			<br>
			<label class="label-text">
				Date:
			</label>
			<input name="date" type="date" class="inputvalues" style="margin-right: 40px;" required/>
			<label class="label-text" style="    margin-left: 45px;">
				Time:
			</label>
            <input type="time" name="time" class="input-text" required >
			<br/>
			<br />
			
			<input name="submit_btn" type="submit" id="signup_btn" value="Book" style="margin: 0 auto;display: block;margin-top: 15px;"/>
			
		</form>
		</div>
	</div>
</div>
			
	  			
<?php
			if(isset($_POST['submit_btn']))
			{
				 $pid =$_POST['pid'];
				 $dname =$_POST['dname'];
				 $cname=$_POST['cname'];
				 $spec =$_POST['spec'];
				$pname =$_POST['pname'];
				$date =$_POST['date'];
			 $time = $_POST['time'];
			  
				 
			 $query= "insert into appointment_list values('','$pid','$dname','$spec','$cname','$pname','$date','$time')";
				
						// $query= "insert into appointment_list values('','$username','$dname','$spec','$cname','$pname','$date','$time')";
						
						//$query= "insert into usersdoc values('','$rname',  '$remail','$encrypted_password','$rmobile','$target_file')";
						//$query= "insert into userscare values('','$rname','$area','$gender','$target_file','$address','$username','$remail','$encrypted_password')";
						$query_run = $con->query($query);	
						$query1= "insert into event values('','$date','$pname','$dname','$time')";
			
						$query_run1 = $con->query($query1);	
						
						if($query_run1)
						{
						 	echo '<script type="text/javascript"> alert("Appointment booked") </script>';
						 }
						else
						{
						 	echo '<script type="text/javascript"> alert("Error!") </script>';
						 }
					
					
					
			}
?> 
</body>
</html>
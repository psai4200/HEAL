<?php
require_once 'dbconfig/config.php';
    if(isset($_POST["reset-password"])){
        $name = $_GET["dname"];
        $password = trim($_POST["password"]);
        $confirmPassword = trim($_POST["confirmPassword"]);
        if($password == $confirmPassword) {
          // $password = password_hash($password, PASSWORD_DEFAULT); 
          $password=md5($password);
           $stmt = $db->prepare("UPDATE usersdoc SET password= ? WHERE dname = ?");
           $stmt->execute(array($password,$name));
           $affected_rows = $stmt->rowCount();
           if($affected_rows) {
               $success_message = "Password is rest successfully.<br>Now you are redirecting";
               header("Refresh:3; url=logindoc.php");
           } else {
               $error_message = "Failed : <br> Password not updated";
           }
        } else {
            $error_message = "Password not matched";
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
<title>Sahara | Reset Password</title>
<link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Noto+Sans+JP:300,400,500" rel="stylesheet">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<link href="style.css" rel="stylesheet">
<style>
    #login-block{
        padding: 30px 65px 65px 60px;
        border-radius: 5px;
        border: solid 1px #000000;
        background-color: #ffffff;
    }
    .label-text{
        font-family: 'Raleway';
        font-size: 24px;
        font-weight: 400;
        text-align: left;
    }
    .input-text{
        margin-left: 11px;
        width: 52%;
    }
    .nav-style{
  list-style-type: none !important;
  border-radius: 20px;
  background-color: #ffffff;
  padding: 10px 30px 10px 30px !important;
  border: solid 2px #92cdd5;
  margin-right: 10px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}

.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
    #reset-password{
        text-align: center;
        border-radius: 25px;
        border: solid 0 #000000;
        background-color: #5796e0;
        width: 50%;
        position: relative;
        left: 120px;
        margin-top: 20px;
        font-family: 'Raleway';
        font-weight: 400;
        font-size: 24px;
        color: white;
        text-transform: uppercase;
    }
    .sidenav {
          background: #92cdd5;
          text-align: center;
          color: black;
          position: fixed;
          left: 0;
          width: 15%;
          min-height: calc(100vh - 0px);
          overflow: auto;
        }
        
        .sidenav a {
          /* padding: 20px 6px 25px 32px; */
          text-decoration: none;
          font-size: 20px;
          color: #000;
          display: block;
          text-align: left;
          margin-left: 20px;
          margin-top: 35px;
          font-family: 'Raleway';
        }
        
        .sidenav a:hover {
          color: #f1f1f1;
        }
</style>
</head>
    <body>
        <nav class="navbar fixed-top navbar-expand-lg navbar-light" style="background-image: linear-gradient( to left,#92cdd5, #ffffff, #ffffff);"  nav-style>
            <a class="navbar-brand" href="#">
                <img src="imgs/SaharaLogo.png" alt="sahara-logo" style="width: 60%;">
            </a>
          
            
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="indexmain.php">Home</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="aboutmain.php">About</a>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            Login
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="logincare.php">Caretaker</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logindoc.php">Doctor</a>
          </div>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Register
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registercare.php">Caretaker</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registerdoc.php">Doctor</a>
            </div>
          </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link" href="helpmain.php">Contact Us</a>
          </li>
      </ul>
    </div>
          </nav>
<!------------------------------------------------------------------------------------------------------->
  <div class="sidenav">
		<h4 style="margin-top: 55%;"></h4>
    	<a href="homepagedoc.php">Home</a>

<?php
	$stmt = $db->prepare('SELECT did, dname, spec, gender, image, address, username, email, password, avai FROM usersdoc ORDER BY did DESC');
	$stmt->execute();
if($stmt->rowCount() > 0)
{
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		extract($row);
		?>
			<a href="aboutdoc.php">About</a>
			<a href="helpdoc.php">Help</a>

		</div>       
		<?php
	}
}
else
{
	?>
	<div class="col-xs-12">
		<div class="alert alert-warning">
			<span class="glyphicon glyphicon-info-sign"></span>&nbsp; No Data Found.
		</div>
	</div>
	<?php
}
?>
<!---------------------------------------------------------------------------------------------------------->
    <div class="container" style="margin-top: 50px;">
            <div class="row" style="margin-top: 30px;">
                <div class="col-md-offset-4 col-md-6" id="login-block">
                    <div style="margin-bottom: 35px;">
                        <h2 style="text-align: center;">Reset Password</h2>
                        <p style="text-align: center;">Provide new password to reset your password</p>
                    </div>
            <form id="reserPassword" name="reserPassword" method="post">
                <?php if(!empty($success_message)) { ?>
                <div class="success_message label-text"style="text-align: center;color: green;margin-bottom: 20px;"><?php echo $success_message ?></div>
                <?php } ?>
                <?php if(!empty($error_message)) { ?>
                <div class="error_message label-text"style="text-align: center;color: red;margin-bottom: 20px;"><?php echo $error_message ?></div>
                <?php } ?>
                <label class="label-text">New Password:</label>
                <input type="password" id="password" name="password" placeholder="Enter a New Password" class="input-text" style="margin-left: 40px;" required>
                <label class="label-text">Retype Password:</label>
                <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm Password" class="input-text" required>
                <input type="submit" value="Reset Password" name="reset-password" id="reset-password">
            </form>
        </div>
    </div>
    </div>
    </body>
</html>

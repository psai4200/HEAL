<?php
ini_set( "display_errors", 0); 
    require 'dbconfig/config.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>Sahara | Doctor Registration </title>
<link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat+Alternates" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans+JP:300,400,500" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700" rel="stylesheet">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<script type="text/javascript">

    function PreviewImage() {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("image").files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("uploadPreview").src = oFREvent.target.result;
        };
    };

</script>
<style>
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("website.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  
}
#login-block{    
	   padding: 10px 45px 20px 45px;
	   border-radius: 5px;
	   border: solid 1px #000000;
	   background-color: #ffffff;
   }
.nav-style{
  list-style-type: none !important;
  
  background-color:#ffffff;
  padding: 10px 30px 10px 30px !important;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}


.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
.about-text{
    padding: 40px;
    padding-top: 0;
    font-size: 18px;
    text-align: justify;
    line-height: 1.5;
    font-family: 'Raleway';
} 
.heading{
	   text-align: center;
	   font-size: 24px;
	   font-family: 'Raleway';
	   text-transform: uppercase;
	   margin-top: -50px;
	   margin-bottom: 75px;
   }
   .heading1{
	   text-align: center;
	   font-size: 24px;
	   font-family: 'Raleway';
	   text-transform: uppercase;
	   margin-top: -50px;
	   margin-bottom: 60px;
   }
   .label-text{
    
	   font-family: 'Raleway';
	   font-size: 22px;
	   font-weight: 400;
	   text-align: left;
   }

      
   
      
   
  
        
      
    
      .myform{
      width: 100%;
      left: 80%;
      bottom: 75%;
      }
      .myformedit{
      width: 50%;
      position: absolute;
      left: 80%;
      bottom: 65%;
      }
      *{
    margin:0;
    padding:0;
    box-sizing: border-box;
    

  }
  .container{
      width 100%;
      height 100vh;
      display: flex;
     
      align-items:center;
      justify-content: center;
      margin-right: 150px;
      margin-left: 150px;

  }
  
@media only screen and (max-width: 1024px){
    html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  width: 100%;
  overflow-x: hidden;
  background-image: url("websiteresize.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  
}
.nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  margin-top: 0px;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}
.row{
  margin-right:300px;
}
}
@media only screen and (max-width: 768px){
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("websiteipad.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
  .nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  margin-top: 0px;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}
.row{
   width: 50%;
}

  
  
}
  
      
</style>
</head>
<body>
<nav class="navbar navbar-fixed-left navbar-expand-lg navbar-light" nav-style>
        <a class="navbar-brand" href="indexmain1.php">
            <img src="SaharaLogo.png" alt="sahara-logo" style="width: 50%;">
        </a>
      
        
      </nav>
       <!------------------------------------------------------------------------------------------------------->
	
       <div class="container" style="margin-top: 50px;margin-bottom: 30px;">
		<div class="row">
			<div class="col-md-offset-1 col-md-12" id="login-block">
				<div>
					<h2 class="heading">Register New Doctor</h2>
				</div>
	<form class="myform" action="registerdocnew.php"method="post" enctype="multipart/form-data" >
		<label class="label-text">
			Full Name: 
		</label>
		<input type="text" name="rname" placeholder="Enter your full Name" class="input-text" style="margin-right: 40px;" required> 
        <br>
		<label for="spec" class="label-text">
			Speciality:
		</label>
		<!-- <input name="spec" type="text" class="inputvalues" placeholder="Your speciality" class="input-text"required/><br> -->
		<select id="spec" name="spec" style="width: 30%;position: relative;bottom: 3px;">
				<option value="general">General Medicine</option>
				<option value="pregnancy">Pregnancy</option>
				<option value="surgery">Surgery</option>
				<option value="neuro">Neurology</option>
				<option value="pediatrics">Pediatrics</option>
				<option value="psycho">Psychology</option>
			</select>
			<br/>
		<label class="label-text">
			Gender:
		</label>
		<select id="gender" name="gender" class="input-text" style="width: 10%; bottom: 0;">
				<option value="male">Male</option>
				<option value="female">Female</option>
				<option value="others">others</option>
		</select>
        <br>
		<label class="label-text">
			Availability:
		</label>
        
			<select id="avai" name="avai">
				<option value="wd 1">Mon-Fri (9AM  - 6PM)</option>
				<option value="wd 2">Mon-Fri (6PM  - 11PM)</option>
				<option value="wd 3">Mon-Fri (12AM - 9AM)</option>
				<option value="we 1">Sat-Sun (9AM  - 5PM)</option>
				<option value="we 2">Sat-Sun (5PM  - 11PM)</option>
				<option value="we 3">Sat-Sun (12AM - 9AM)</option>
			</select>
        <br>
</br>
		
		
		<br>
		<label class="label-text" style="position: relative;bottom: 15px;">
			Address:
		</label>
		<textarea rows="2" cols="70" name="address" style="margin-left:10px;"></textarea>
			<br>
			<br />
		<label class="label-text">
			Username:
		</label>
		<input name="username" type="text" class="inputvalues" placeholder="Type your username" style="margin-right: 40px;" required/>
        <br>
        <label class="label-text">
			Email ID:
		</label>
		<input type="email" name="remail" placeholder="Enter Valid Email" class="input-text" required >
        <br/>
		<br />
		<label class="label-text">
			Password:
		</label>
		<input type="password" name="rpassword" placeholder="Password" class="input-text" required >
        <br>
		<label class="label-text" style="margin-left: 0px;">
	    Confirm Password:
		</label>
		<input name="cpassword" type="password" class="inputvalues" placeholder="Confirm password" class="input-text" style="margin-left: 15px;margin-right: 40px;"  required/><br>
		<br/>
        <span style="margin-left: 5%;">
			<img id="uploadPreview" src="imgs/patient.png" class="avatar"/>
			<input type="file" id="image" name="image" accept=".jpg,.jpeg,.png" onchange="PreviewImage();" class="label-text" style="display: inline;margin-left: 20px;"/>
		</span>
		<br>
        
		<input  class="btn btn-primary" name="submit_btn" type="submit" id="signup_btn" value="Register"style="margin: 0 auto;display: block;margin-top: 15px; width: 15%;"/><br>
		<p class="label-text" style="text-align: center; margin-top: 5px;">Already a member? <a href="logindoc.php">Login</a></p>
		</form>
        
 <?php
			if(isset($_POST['submit_btn']))
			{
				
				//  $first =$_POST['first'];
				//  $last=$_POST['last'];
				 $spec =$_POST['spec'];
				 $gender =$_POST['gender'];
				 $address =$_POST['address'];
				$username = $_POST['username'];
				
				// $password = $_POST['password'];
				 $cpassword = $_POST['cpassword'];
				 $avai =$_POST['avai'];
				// $email = $_POST['mail'];
				
				$img_name = $_FILES['image']['name'];
				$img_size =$_FILES['image']['size'];
			    $img_tmp =$_FILES['image']['tmp_name'];
				$rname = trim($_POST["rname"]);
				$remail = trim($_POST["remail"]);
				$rpassword = trim($_POST["rpassword"]);
				//$rmobile = trim($_POST["rmobile"]);
				
				 $directory = 'uploads/';
				 $target_file = $directory.$img_name;
				
				if($rpassword==$cpassword)
				{
					
					$encrypted_password = md5($rpassword);
					//$query= "select * from users WHERE username='$username'";
					$query= "SELECT email FROM usersdoc WHERE email='{$remail}'";
					$query_run = $con->query($query);	
					//if(mysqli_num_rows($query_run)>0)
					//if($query_run->num_rows>0)
					if($query_run->num_rows>0)
					{
						// there is already a user with the same username
						echo '<script type="text/javascript"> alert("User already exists.. try another username") </script>';
					}
					else if(file_exists($target_file))
					{
						echo '<script type="text/javascript"> alert("Image file already exists.. Try another image file") </script>';
					}
					
					else if($img_size>2097152)
					{
						echo '<script type="text/javascript"> alert("Image file size larger than 2 MB.. Try another image file") </script>';
					}
					
					else
					{
						move_uploaded_file($img_tmp,$target_file); 	
						//$query= "insert into usersdoc values('','$rname',  '$remail','$encrypted_password','$rmobile','$target_file')";
						$query= "insert into usersdoc values('','$rname','$spec','$gender','$target_file','$address','$username','$remail','$encrypted_password','$avai')";
						$query_run = $con->query($query);	
						
						
						if($query_run)
						{
						 	echo '<script type="text/javascript"> alert("User Registered.. Go to login page to login") </script>';
						 }
						else
						{
						 	echo '<script type="text/javascript"> alert("Error!") </script>';
						 }
					}	
					
					
				}
				else
				{
					echo '<script type="text/javascript"> alert("Password and confirm password does not match!")</script>';	
				}
			}
		?> 
</body>
</html>
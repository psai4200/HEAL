<?php
ini_set( "display_errors", 0); 
	require 'dbconfig/config.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>Sahara | Caretaker Registration </title>
<link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat+Alternates" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans+JP:300,400,500" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700" rel="stylesheet">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

<script type="text/javascript">

    function PreviewImage() {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("image").files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("uploadPreview").src = oFREvent.target.result;
        };
    };

</script>
<style>
	 #login-block{    
		padding: 10px 45px 20px 45px;
		border-radius: 5px;
		border: solid 1px #000000;
		background-color: #ffffff;
	}
	.myform{
		width: 100%;
	}
	.label-text{
        font-family: 'Raleway';
        font-size: 22px;
        font-weight: 400;
        text-align: left;
    }
    .input-text{
		margin-left: 10px;
		width: 30%;
		position: relative;
		bottom: 3px;
		margin-right: 20px;
	}
    #signup_btn{
		text-align: center;
		border-radius: 25px;
		border: solid 0 #000000;
		background-color: #5796e0;
		width: 50%;
		position: relative;
		margin-top: 20px;
		font-family: 'Raleway';
		font-weight: 400;
		font-size: 24px;
        color: white;
		text-transform: uppercase;
	}
	.inputvalues{
		width: 30%;
		position: relative;
		bottom: 3px;
		margin-left: 10px;
	}
	.heading{
		text-align: center;
		font-size: 24px;
		font-family: 'Raleway';
		text-transform: uppercase;
		margin-top: 10px;
		margin-bottom: 35px;
	}
	.avatar{
		width: 12%;
		margin-top: 5px;
    	margin-bottom: 10px;
	}
	.nav-style{
		list-style-type: none !important;
		border-radius: 20px;
		background-color: #ffffff;
		padding: 10px 30px 10px 30px !important;
		border: solid 2px #92cdd5;
		margin-right: 10px;
		font-family: 'Raleway';
		font-size: 18px;
		letter-spacing: 1px;
	}

	.dropdown-item{
		padding: 0px 10px;
    	font-size: 18px;
	}
	.dropdown-menu{
		padding: 15px;
		width: 250px;
		border-radius: 10px;
		box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
		background: #fff;
	}
	
</style>
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-expand-lg navbar-light" style="background-image: linear-gradient( to left,#92cdd5, #ffffff, #ffffff);">
        <a class="navbar-brand" href="#">
            <img class="" src="imgs/SaharaLogo.png" alt="sahara-logo" style="width: 60%;">
        </a>
      
		
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="indexmain.php">Home</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="aboutmain.php">About</a>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            Login
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="logincare.php">Caretaker</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logindoc.php">Doctor</a>
          </div>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Register
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
             
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registercare.php">Caretaker</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registerdoc.php">Doctor</a>
            </div>
          </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link" href="helpmain.php">Contact Us</a>
          </li>
      </ul>
    </div>
      </nav>

	  <!-- BODY CONTENT -->
	  <div class="container" style="margin-left: 150px; margin-top: 120px;">
		<div class="row">
			<div class="col-md-12" id="login-block">
				<div>
					<h2 class="heading">Register New Caretaker</h2>
				</div>
	<form class="myform" action="registercare.php"method="post" enctype="multipart/form-data" >
			<label class="label-text">
				Full Name: 
			</label>
			<input type="text" name="rname" placeholder="Enter your full Name" class="input-text" style="margin-right: 40px;"required> 
			<label class="label-text">
				Area/Region:
			</label>
			<input name="area" type="text" class="inputvalues" placeholder="Enter Area" class="input-text" required/><br>
			<label class="label-text">
				Gender:
			</label>
			<select id="gender" name="gender" class="input-text" style="width: 10%; bottom: 0;">
				<option value="male">Male</option>
				<option value="female">Female</option>
				<option value="others">others</option>
			</select>
			<span style="margin-left: 15%;">
				<img id="uploadPreview" src="imgs/man.png" class="avatar"/>
				<input type="file" id="image" name="image" accept=".jpg,.jpeg,.png" onchange="PreviewImage();" class="label-text" style="display: inline;margin-left: 20px;"/>
			</span>
			<br>
			<label class="label-text" style="position: relative;bottom: 15px;">
				Address:
			</label>
			<textarea rows="2" cols="120" name="address" style="margin-left:10px;"></textarea>
			<br>
			<br />
			<label class="label-text">
				Username:
			</label>
			<input name="username" type="text" class="inputvalues" placeholder="Type your username" style="margin-right: 40px;" required/>
			<label class="label-text">
				Email ID:
			</label>
            <input type="email" name="remail" placeholder="Enter Valid Email"class="input-text" required >
			<br/>
			<br />
			<label class="label-text">
				Password:
			</label>
            <input type="password" name="rpassword" placeholder="Password" class="input-text" style="margin-left: 15px;margin-right: 40px;" required >
			<label class="label-text">
				Confirm Password:
			</label>
			<input name="cpassword" type="password" class="inputvalues" placeholder="Confirm password" required/>
			<br/>
			<br />
			<input name="submit_btn" type="submit" id="signup_btn" value="Register" style="margin: 0 auto;display: block;margin-top: 15px;"/>
			<p class="label-text" style="text-align: center; margin-top: 5px;">Already a member? <a href="logincare.php">Login</a></p>
		</form>
		</div>
	</div>
</div>
		
<?php
			if(isset($_POST['submit_btn']))
			{
				$area =$_POST['area'];
				$gender =$_POST['gender'];
				$address =$_POST['address'];
			   $username = $_POST['username'];
			   
			   // $password = $_POST['password'];
				$cpassword = $_POST['cpassword'];
			
			   // $email = $_POST['mail'];
			   
			   $img_name = $_FILES['image']['name'];
			   $img_size =$_FILES['image']['size'];
			   $img_tmp =$_FILES['image']['tmp_name'];
			   $rname = trim($_POST["rname"]);
			   $remail = trim($_POST["remail"]);
			   $rpassword = trim($_POST["rpassword"]);
				//  $first =$_POST['first'];
				//  $last=$_POST['last'];
				//  $area =$_POST['area'];
				//  $gender =$_POST['gender'];
				//  $address =$_POST['address'];
				// $username = $_POST['username'];
				// $cpassword = $_POST['cpassword'];
				
				// $password = $_POST['password'];
				 
				 //$avai =$_POST['avai'];
				// $email = $_POST['mail'];
				
				// $img_name = $_FILES['image']['name'];
				// $img_size =$_FILES['image']['size'];
			    // $img_tmp =$_FILES['image']['tmp_name'];
				// $rname = trim($_POST["rname"]);
				// $remail = trim($_POST["remail"]);
				// $rpassword = trim($_POST["rpassword"]);
				//$rmobile = trim($_POST["rmobile"]);
				
				 $directory = 'uploads/';
				 $target_file = $directory.$img_name;
				
				if($rpassword==$cpassword)
				{
					
					$encrypted_password = md5($rpassword);
					//$query= "select * from users WHERE username='$username'";
					$query= "SELECT email FROM userscare WHERE email='{$remail}'";
					$query_run = $con->query($query);	
					if($query_run->num_rows>0)
					//if($query_run->num_rows>0)
					{
						// there is already a user with the same username
						echo '<script type="text/javascript"> alert("User already exists.. try another username") </script>';
					}
					else if(file_exists($target_file))
					{
						echo '<script type="text/javascript"> alert("Image file already exists.. Try another image file") </script>';
					}
					
					else if($img_size>2097152)
					{
						echo '<script type="text/javascript"> alert("Image file size larger than 2 MB.. Try another image file") </script>';
					}
					
					else
					{
						move_uploaded_file($img_tmp,$target_file); 	
						$query= "insert into userscare values('','$rname','$area','$gender','$target_file','$address','$username','$remail','$encrypted_password')";
						//$query= "insert into usersdoc values('','$rname',  '$remail','$encrypted_password','$rmobile','$target_file')";
						//$query= "insert into userscare values('','$rname','$area','$gender','$target_file','$address','$username','$remail','$encrypted_password')";
						$query_run = $con->query($query);
						
						if($query_run)
						{
						 	echo '<script type="text/javascript"> alert("User Registered.. Go to login page to login") </script>';
						 }
						else
						{
						 	echo '<script type="text/javascript"> alert("Error!") </script>';
						 }
					}	
					
					
					
				}
				else
				{
					echo '<script type="text/javascript"> alert("Password and confirm password does not match!")</script>';	
				}
				
			}
			
		?>
</body>
</html>
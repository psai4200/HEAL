<?php
ini_set( "display_errors", 0); 
ob_start();
	session_start();
	require 'dbconfig/config.php';
	
	
?>

<!DOCTYPE html>
<html>
<head>
<title>Sahara | Login Page</title>
<link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Noto+Sans+JP:300,400,500" rel="stylesheet">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<style>
	#login-block{
		padding: 30px 65px 65px 60px;
		border-radius: 5px;
		border: solid 1px #000000;
		background-color: #ffffff;
	}
	.label-text{
		font-family: 'Raleway';
		font-size: 24px;
		font-weight: 400;
		text-align: left;
	}
	.input-text{
		margin-left: 20px;
		width: 60%;
	}
	#login_btn{
		text-align: center;
		border-radius: 25px;
		border: solid 0 #000000;
		background-color: #5796e0;
		width: 50%;
		position: relative;
		left: 120px;
		margin-top: 20px;
		font-family: 'Raleway';
		font-weight: 400;
		font-size: 24px;
		text-transform: uppercase;
	}
	.reg-text{
		font-family: 'Raleway';
    	font-size: 20px;
	}
	.nav-style{
          list-style-type: none !important;
          border-radius: 20px;
          background-color: #ffffff;
          padding: 10px 30px 10px 30px !important;
          border: solid 2px #92cdd5;
          margin-right: 10px;
          font-family: 'Raleway';
          font-size: 18px;
          letter-spacing: 1px;
        }

        .dropdown-item{
          padding: 0px 10px;
            font-size: 18px;
        }
        .dropdown-menu{
          padding: 15px;
          width: 250px;
          border-radius: 10px;
          box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
          background: #fff;
        }
</style>
</head>
<body>
<div class="container">

	<nav class="navbar navbar-fixed-top navbar-expand-lg navbar-light" style="background-image: linear-gradient( to left,#92cdd5, #ffffff, #ffffff);">
		<a class="navbar-brand" href="#">
			<img class="" src="imgs/SaharaLogo.png" alt="sahara-logo" style="width: 60%;">
		</a>
	  
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="indexmain.php">Home</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="aboutmain.php">About</a>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            Login
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="logincare.php">Caretaker</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logindoc.php">Doctor</a>
          </div>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Register
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
             
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registercare.php">Caretaker</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registerdoc.php">Doctor</a>
            </div>
          </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link" href="helpmain.php">Contact Us</a>
          </li>
      </ul>
    </div>
	  </nav>
	  <!---------------------------------------------------------------------------------------------------------->
<div class="row" style="margin-top: 150px;">
	<div class="col-md-offset-3 col-md-6" id="login-block">
		<div style="margin-bottom: 35px;">
			<h2 style="text-align: center;">Login Form</h2>
			<p style="text-align: center;">Login to access your account</p>
		</div>
		<form class="myform" action="logincare.php" method="post">
			<!-- <label><b>Username:</b></label><br>
			<input name="username" type="text" class="inputvalues" placeholder="Type your username" required/><br>
			<label><b>Password:</b></label><br>
			<input name="password" type="password" class="inputvalues" placeholder="Type your password" required/><br> -->
			<label class="label-text">
				Email ID: 
			</label>
			<input type="email" name="lemail" placeholder="Enter a valid Email" class="input-text" style="margin-left: 40px;" required>
			<br/>
			<label class="label-text">
				Password:
			</label>
            <input type="password" name="lpassword" placeholder="Enter your password" class="input-text" style="margin-left: 22px;" required>
			<input name="login" type="submit" id="login_btn" value="Login"/>
			<br />
			<!------------------------------------------------------>
			<p class="reg-text" style="margin-top: 20px;">Don't have an account?<a href="registercare.php"> Register</a></p>
			<p class="reg-text"><a href="forgetPasswordcare.php">Forget Password?</a></p>
		</form>
		
		<?php
		if(isset($_POST['login']))
		{
			// $username=$_POST['username'];
			// $password=$_POST['password'];
			$email =trim($_POST["lemail"]);
$password =trim($_POST["lpassword"]);
			$encrypted_password = md5($password);
			
			//$query="select * from users WHERE username='$username' AND password='$encrypted_password'";
			$query="select * from userscare WHERE email ='$email' AND password='$encrypted_password'";
			
			$query_run = $con->query($query);	
					//if(mysqli_num_rows($query_run)>0)
			if($query_run->num_rows>0)
			
			//$query_run = $con->query($query);	
			//if(mysqli_num_rows($query_run)>0)
			{
				$row= $query_run->fetch_assoc();
				//$row=$result->store_result();
				//$row1=$query_run->fetch(PDO::FETCH_ASSOC);
				//$row =$query_run->fetch_assoc();
				//echo $row;
				// valid
				// $_SESSION['username']= $row['username'];
				// $_SESSION['image']= $row['image'];
				header('location:homepagecare.php');
			}
			else
			{
				// invalid
				echo '<script type="text/javascript"> alert("Invalid credentials") </script>';
			}
			
		}
	
		?>  
		
	</div>
</div>
</div>
</body>
</html>
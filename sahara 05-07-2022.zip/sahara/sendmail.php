<?php
require 'vendor/autoload.php';
define("PROJECT_NAME", "http://localhost/finaloffinal/");
$mail = new PHPMailer\PHPMailer\PHPMailer;
//Enable SMTP debug mode
$mail->SMTPDebug = 0;
//set PHPMailer to use SMTP
$mail->isSMTP();
//set host name
$mail->Host = "smtp.gmail.com";
// set this true if SMTP host requires authentication to send mail
$mail->SMTPAuth = true;
//Provide username & password
$mail->Username = "dancerdivya79@gmail.com";
$mail->Password = "12divya34kavya";
$mail->SMTPSecure = "tls";
$mail->Port = 587;

$mail->From = "dhathwar91@gmail.com";
$mail->FromName = "Divya P Hathwar";
$mail->addAddress($_POST["user-email"]);
$mail->isHTML(true);

$mail->Subject = "Book an appointment";
$mail->Body="<div>".$user[0]["name"]."<br><br><p>wants to book an appointment.<br> Check your homepage for the appointment date.<br>
<br><br></p>Regards<br> Admin.</div>";
        if(!$mail->send()) {
            $error_message = "Mailer Error : ". $mail->ErrorInfo;
        } else {
            $success_message = "Message has been sent successfully";
        }
        

      ?> 


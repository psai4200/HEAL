<?php
ob_start();
   session_start();
	error_reporting( ~E_NOTICE );
	require_once 'dbconfig/config.php';
	
	 if(isset($_SESSION['doctor_id']) && !empty($_SESSION['doctor_id']))
	 {
	 	$did = $_SESSION['doctor_id'];
	 	$stmt_edit = $db->prepare('SELECT username, address,dname, email,password, image FROM usersdoc WHERE did =:uid');
	 	$stmt_edit->execute(array(':uid'=>$did));
	 	$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	 	extract($edit_row);
	 }
	 else
	 {
	 	header("Location: commonlogin.php");
	 }
	if(isset($_POST['btn_save_updates']))
	{
		$username = $_POST['user_name'];
		$password =$_POST['rpassword'];
		$cpassword = $_POST['cpassword'];
		$address = $_POST['address'];	
		$dname = $_POST['rname'];	
		$email = $_POST['email'];	
		$imgFile = $_FILES['image']['name'];
		$tmp_dir = $_FILES['image']['tmp_name'];
		$imgSize = $_FILES['image']['size'];
		if($imgFile)
		{
			$upload_dir = 'uploads/';
			$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION));
			$valid_extensions = array('jpeg', 'jpg', 'png', 'gif');
			$image = rand(1000,1000000).".".$imgExt;
			if(in_array($imgExt, $valid_extensions))
			{			
				if($imgSize < 5000000)
				{
					unlink($upload_dir.$edit_row['image']);
					move_uploaded_file($tmp_dir,$upload_dir.$image);
				}
				else
				{
					$errMSG = "Sorry, Your File Is Too Large To Upload. It Should Be Less Than 5MB.";
				}
			}
			else
			{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF Extension Files Are Allowed.";		
			}	
		}
		else
		{
			$userprofile = $edit_row['image'];
		}
		if($password==$cpassword)
				{
					
					$encrypted_password = md5($password);
				}
				else
				{
					echo '<script type="text/javascript"> alert("Password and confirm password does not match!")</script>';	
				}
		if(!isset($errMSG))
		{
		

			$stmt = $db->prepare('UPDATE usersdoc SET username=:uname, address=:uad, dname=:ufname, email=:uemail,password=:upassword, image=:upic WHERE did=:uid');
			$stmt->bindParam(':uname',$username);
			
			$stmt->bindParam(':uad',$address);
			$stmt->bindParam(':ufname',$dname);
			$stmt->bindParam(':uemail',$email);
			$stmt -> bindParam(':upassword',$encrypted_password);
			$stmt->bindParam(':upic',$image);
			$stmt->bindParam(':uid',$did);
				
			if($stmt->execute()){
				?>
                <script>
				alert('Successfully Updated...');
				window.location.href='homepagedoc.php';
				</script>
                <?php
			}
			else{
				$errMSG = "Sorry User Could Not Be Updated!";
			}
		}			
	}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<title>Sahara | Doctor's Homepage</title>
<style>
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("website.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  
}
.nav-style{
  list-style-type: none !important;
  
  background-color:#ffffff;
  padding: 10px 30px 10px 30px !important;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}


.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
.about-text{
    padding: 40px;
    padding-top: 0;
    font-size: 18px;
    text-align: justify;
    line-height: 1.5;
    font-family: 'Raleway';
} 
.heading{
	   text-align: center;
	   font-size: 24px;
	   font-family: 'Raleway';
	   text-transform: uppercase;
	   margin-top: -50px;
	   margin-bottom: 75px;
   }
   .heading1{
	   text-align: center;
	   font-size: 24px;
	   font-family: 'Raleway';
	   text-transform: uppercase;
	   margin-top: -50px;
	   margin-bottom: 60px;
   }
   .label-text{
      width: 50%;
      font-family: 'Raleway';
      font-size: 22px;
      font-weight: 400;
      text-align: left;
      border: black solid 1px;
      padding: 5px 20px;
      min-width: 160px;
      max-width: 160px;
      
   }
   .sidenav {
          background: #92cdd5;
          text-align: center;
          color: black;
          
          left: 0;
          width: 15%;
          min-height: calc(100vh - 0px);
          overflow: auto;
        }
        
        .sidenav a {
          /* padding: 20px 6px 25px 32px; */
          text-decoration: none;
          font-size: 20px;
          color: #000;
          display: block;
          text-align: left;
          margin-left: 20px;
          margin-top: 35px;
          font-family: 'Raleway';
        }
        
        .sidenav a:hover {
          color: #f1f1f1;
        }
        #logout_btn {
          margin-top: -220px;
          background-color: #c0392b;
          padding: 5px;
          color: white;
          width: 30%;
          text-align: center;
          font-size: 18px;
          font-weight: bold;
          margin-bottom: 20px;
          margin-left: 10px;
      }
      
    
      .myform{
      width: 50%;
      left: 80%;
      bottom: 75%;
      }
      .myformedit{
      width: 50%;
      position: absolute;
      left: 80%;
      bottom: 65%;
      }
      *{
    margin:0;
    padding:0;
    box-sizing: border-box;
    

  }
  .container{
      width 100%;
      height 100vh;
      display: flex;
      align-items:center;
      justify-content: center;

  }
  .profile-box{
      width: 60%;
      background: #ff574a;
      text-align: center;
      padding: 40px 90px;
      color: #fff;
      position: relative;
      border-radius: 20px;
  }
  .setting-icon{
      width: 25px;
      position: absolute;
      right: 40px;
      top: 40px;
  }
  .profile-pic{
      width: 150px;
      border-radius: 50%;
      background: #fff;
      padding : 6px;
      

  }
  .profile-box h2{
      font-size: 22px;
      margin-top: 20px;
      font-weight: 500;
      text-align: left;
      width: 100%;

  }
 
  @media only screen and (max-width: 1024px){
    html, body {
    margin: 0;
    padding: 0;
    
    height:100vh;
  width: 100vw;
  overflow-x: hidden;
  background-image: url("websiteresize.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  
}
.nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  margin-top: 0px;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}

  
  }
@media only screen and (max-width: 768px){
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("websiteipad.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
  .nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  margin-top: 0px;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}
.profile-box{
      width: 70%;
      background: #ff574a;
      text-align: center;
      padding: 40px 90px;
      color: #fff;
      position: relative;
      border-radius: 20px;
  }
  
  
}
  
      
</style>
</head>
<body>

    <nav class="navbar navbar-fixed-left navbar-expand-lg navbar-light" nav-style>
        <a class="navbar-brand" href="indexmain.php">
            <img src="SaharaLogo.png" alt="sahara-logo" style="width: 50%;">
        </a>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important; margin-left: 180px;">
          <a class="nav-link" href="homepagedoc.php" >Home</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="aboutmain.php" >About</a>
        </li>
        
        
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link" href="helpmain.php" >Contact Us</a>
          </li>
     
          <form class="nav-item nav-style" action="homepagedoc.php" method="post" style="margin-left:600px; margin-right:-50px; background-color: rgba(0,0,0,0); margin-top:-10px;">
				<button name="logout" type="submit" id="nav-link" class="btn btn-primary">Log Out</button>
			</form>
            


      </ul>
    </div>
      </nav>
       <!------------------------------------------------------------------------------------------------------->

<!------------------------------------------------------------------------------------------------------>






 <!---------------------------------------------------------------------------------------------->

<!------------------------------------------------------------------------------------------------------>
<?php
	$stmt = $db->prepare('SELECT did, dname, spec, gender, image, address, username, email, password, avai FROM usersdoc WHERE did=?');
	$stmt->execute([$did]);
if($stmt->rowCount() > 0)
{
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		extract($row);
		?>
	<div class="container" style="margin-left:135px; margin-right:0px; background-color: #ffffff; ">
			<span>
      <a   class="btn btn-primary" href="editprofiledocnew.php?edit_id=<?php echo $row['did']; ?>">Edit</a> 
			<a  class="btn btn-primary" href="?delete_id=<?php echo $row['did']; ?>" title="click for delete" onclick="return confirm('Are You Sure You Want To Delete This User?')">Delete</a>
			</span>
			</p>
			
		</div>       
		<?php
	}
}
else
{
	?>
	<div class="col-xs-12">
		<div class="alert alert-warning">
			<span class="glyphicon glyphicon-info-sign"></span>&nbsp; No Data Found.
		</div>
	</div>
	<?php
}
?>
<div class="container-fluid h-100" style="width: 50%; margin-right: 24%; margin-bottom: 8%; margin-top: 8%; background-color: #F0F8FF; margin-radius: 15%">
		<div class="row">
			<div class="col-md-12">
				<div>
					<h2 class="heading">Edit Profile</h2>
					<a class="btn btn-success" href="homepagedoc.php" style="position: relative; bottom: 40px;left: 88%;"><span class="glyphicon glyphicon-home"></span>&nbsp; Back</a>
				</div>
<form method="post" enctype="multipart/form-data" class="form-horizontal" style="border: solid 1px;border-radius:4px">
    <?php
	if(isset($errMSG)){
		?>
        <div class="alert alert-danger">
          <span class="glyphicon glyphicon-info-sign"></span> &nbsp; <?php echo $errMSG; ?>
        </div>
        <?php
	}
	?>
	<table class="table table-responsive">
    <tr>
    	<td><label class="control-label label-text">Username</label></td>
        <td><input class="form-control" type="text" name="user_name" value="<?php echo $username; ?>" required /></td>
    </tr>
 
	<tr>
    	<td><label class="control-label label-text">Address</label></td>
        <td><textarea class="form-control" rows="2" cols="130" name="address"  value="<?php echo $address; ?>" required></textarea></td>
    </tr>
	<tr>
    	<td><label class="control-label label-text">Name</label></td>
        <td><input class="form-control" type="text" name="rname" value="<?php echo $dname; ?>" required /></td>
    </tr>
	<tr>
    	<td><label class="control-label label-text">Mail</label></td>
        <td><input class="form-control" type="email" name="email" value="<?php echo $email; ?>" required /></td>
    </tr>	
	<tr>
    	<td><label class="control-label label-text">Password</label></td>
        <td><input class="form-control" type="password" name="rpassword"  required /></td>
    </tr>	
	<tr>
    	<td><label class="control-label label-text" style="text-align: left;">Confirm password</label></td>
        <td><input class="form-control" type="password" name="cpassword"  required /></td>
    </tr>	
    	<tr><td><label class="control-label label-text" style="text-align: left;">Profile Picture</label></td>
        <td>
        	<p><img src="uploads/<?php echo $image; ?>" height="150" width="150" /></p>
        	<input class="input-group" type="file" name="image" accept="image/*" />
        </td>
    </tr>
    <tr>
        <td colspan="2" allign="center">
		<button type="submit" name="btn_save_updates" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-save"></span>&nbsp; Save</button>
        <a class="btn btn-warning" href="homepagedoc.php"> <span class="glyphicon glyphicon-remove"></span>&nbsp; Cancel</a>
        </td>
    </tr>
    </table>
</form>
</div></div></div>
<?php
			if(isset($_POST['logout']))
			{
				session_destroy();
				header('location:commonlogin.php');
			}
		?>
    
	

</div>
</div>

</body>
</html>
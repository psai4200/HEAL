-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2021 at 04:34 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finalyear`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment_list`
--

CREATE TABLE `appointment_list` (
  `id` int(30) NOT NULL,
  `pid` int(20) NOT NULL,
  `dname` varchar(40) NOT NULL,
  `spec` varchar(40) NOT NULL,
  `cname` varchar(40) NOT NULL,
  `pname` varchar(40) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment_list`
--

INSERT INTO `appointment_list` (`id`, `pid`, `dname`, `spec`, `cname`, `pname`, `date`, `time`) VALUES
(47, 22, 'Divya P Hathwar', 'general', 'kavya', 'yash', '2021-05-30', '21:49:00');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `event_id` int(5) NOT NULL,
  `date` date NOT NULL,
  `pname` varchar(256) NOT NULL,
  `dname` varchar(40) NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `date`, `pname`, `dname`, `time`) VALUES
(11, '2021-05-28', 'aish', 'Divya P Hathwar', '17:57:00'),
(12, '2021-05-28', 'aish', 'Divya P Hathwar', '17:57:00'),
(13, '2021-05-28', 'aish', 'Divya P Hathwar', '20:26:00'),
(14, '2021-05-29', 'aish', 'Divya P Hathwar', '20:02:00'),
(15, '2021-05-28', 'aish', 'Divya P Hathwar', '20:17:00'),
(16, '2021-05-30', 'yash', 'Divya P Hathwar', '21:49:00');

-- --------------------------------------------------------

--
-- Table structure for table `userscare`
--

CREATE TABLE `userscare` (
  `cid` int(11) NOT NULL,
  `cname` varchar(40) NOT NULL,
  `area` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `image` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userscare`
--

INSERT INTO `userscare` (`cid`, `cname`, `area`, `gender`, `image`, `address`, `username`, `email`, `password`) VALUES
(7, 'kavya', 'Karnataka', 'male', 'uploads/spaceo-PHP1-5.png', '66/7 c main corporation layout 4th T block\r\nJayanagar', 'kavya', 'kavya@gmail.com', 'e7476ca55559e029965da4e8f1018e45');

-- --------------------------------------------------------

--
-- Table structure for table `usersdoc`
--

CREATE TABLE `usersdoc` (
  `did` int(11) NOT NULL,
  `dname` varchar(40) NOT NULL,
  `spec` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `image` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `avai` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usersdoc`
--

INSERT INTO `usersdoc` (`did`, `dname`, `spec`, `gender`, `image`, `address`, `username`, `email`, `password`, `avai`) VALUES
(29, 'Divya P Hathwar', 'general', 'female', 'uploads/images.png', '66/7 c main corporation layout 4th T block\r\nJayanagar', 'dhathwar91', 'dhathwar91@gmail.com', '2cdd7064b290132617248dbfd85f740e', 'wd 1');

-- --------------------------------------------------------

--
-- Table structure for table `userspatient`
--

CREATE TABLE `userspatient` (
  `pid` int(11) NOT NULL,
  `pname` varchar(40) NOT NULL,
  `age` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `image` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userspatient`
--

INSERT INTO `userspatient` (`pid`, `pname`, `age`, `gender`, `image`, `address`, `username`, `email`, `password`, `date`) VALUES
(21, 'aish', '45', 'female', 'uploads/images (1).jpg', '66/7 c main corporation layout 4th T block\r\nJayanagar', 'aish', 'aish@gmail.com', 'c32bcd02d43ddd15b9f035b4e22bcc59', '2021-05-27'),
(22, 'yash', '20', 'male', 'uploads/images (3).jpg', 'jayanagar', 'yash', 'yash@gmail.com', 'c296539f3286a899d8b3f6632fd62274', '2021-05-27');

-- --------------------------------------------------------

--
-- Table structure for table `visited_list`
--

CREATE TABLE `visited_list` (
  `id` int(11) NOT NULL,
  `pid` int(20) NOT NULL,
  `dname` varchar(20) NOT NULL,
  `spec` varchar(40) NOT NULL,
  `cname` varchar(40) NOT NULL,
  `pname` varchar(20) NOT NULL,
  `image` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `visited_list`
--

INSERT INTO `visited_list` (`id`, `pid`, `dname`, `spec`, `cname`, `pname`, `image`, `date`, `time`) VALUES
(46, 21, 'Divya P Hathwar', 'general', 'kavya', 'aish', 'uploads/images (1).jpg', '2021-05-28', '20:17:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment_list`
--
ALTER TABLE `appointment_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Test` (`pid`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`),
  ADD UNIQUE KEY `event_id` (`event_id`);

--
-- Indexes for table `userscare`
--
ALTER TABLE `userscare`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `usersdoc`
--
ALTER TABLE `usersdoc`
  ADD PRIMARY KEY (`did`),
  ADD UNIQUE KEY `address` (`did`);

--
-- Indexes for table `userspatient`
--
ALTER TABLE `userspatient`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `visited_list`
--
ALTER TABLE `visited_list`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment_list`
--
ALTER TABLE `appointment_list`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `userscare`
--
ALTER TABLE `userscare`
  MODIFY `cid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `usersdoc`
--
ALTER TABLE `usersdoc`
  MODIFY `did` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `userspatient`
--
ALTER TABLE `userspatient`
  MODIFY `pid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `visited_list`
--
ALTER TABLE `visited_list`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

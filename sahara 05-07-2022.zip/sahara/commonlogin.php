<?php
ini_set( "display_errors", 0); 
session_start();
ob_start();
	
	require 'dbconfig/config.php';
	
	
?>
<!DOCTYPE html>
<html>
<head>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sahara | Home Page</title>
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Noto+Sans+JP:300,400,500" rel="stylesheet">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<style>
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("website.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  }
  
  
  .nav-style{
  list-style-type: none !important;
  
  background-color:#ffffff;
  padding: 10px 30px 10px 30px !important;
  
  margin-top: 0px;
  margin-left:00px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}

.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
.heromodule{
    /* background: linear-gradient(180deg, rgba(181,237,251,1) 0%, rgba(251,255,252,1) 39%, rgba(255,249,194,1) 100%); */
    position: absolute;
    margin-left: 350px;
}
.aligntext{
    text-align: center;
}
.input-text{
		margin-left: 20px;
		width: 60%;
	}
.hero-text{
  font-family: 'Raleway';
  color: #2c5e8a;
  font-weight: 600;
  text-transform: capitalize;
  padding: 20px 0 0;
  font-size: 55px;
  text-align: left;
  line-height: 1.2;
}
.hero-subtext{
  font-family: 'Noto Sans JP', sans-serif;
  font-size: 20px;
  text-align: left;
  color: #6a6a77;
}
.visit-text{
  font-family: 'Noto Sans JP', sans-serif;
  font-size: 22px;
  text-align: left;
  color: #6a6a77;
  padding-top: 10px;
}
.visit-head{
  font-size: 40px;
  font-weight: 500;
  color: #3c6890;
}
.reg-text{
		font-family: 'Raleway';
    	font-size: 20px;
	}
    .label-text{
		font-family: 'Raleway';
		font-size: 24px;
		font-weight: 400;
		text-align: left;
	}




#login-block{
		padding: 30px 65px 65px 60px;
		border-radius: 5px;
		border: solid 1px #000000;
		background-color: #ffffff;
	}
    #login_btn{
		text-align: center;
		border-radius: 25px;
		border: solid 0 #000000;
		background-color: #5796e0;
		width: 50%;
		position: absolute;
		left: 120px;
		margin-top: 130px;
        margin-left: 80px;
		font-family: 'Raleway';
		font-weight: 400;
		font-size: 24px;
		text-transform: uppercase;
	}
  
  
@media only screen and (max-width: 1024px){
    html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  width: 100%;
  overflow-x: hidden;
  background-image: url("websiteresize.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  
}
.heromodule{
 margin-left: 200px;
}
.nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  
  
  margin-right: 50px;
  margin-left: 900px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}


  
  }
@media only screen and (max-width: 768px){
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("websiteipad.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.heromodule{
 margin-left: 10px;
 margin-top: 140px;
 
 align: center;
}
  .nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  
  
  margin-right: 50px;
  margin-left: 625px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}
.navbar-brand{
 
}
}

      
</style>
</head>
<body>

 
        <a class="navbar-brand" href="indexmain1.php">
            <img src="SaharaLogo.png" alt="sahara-logo" style="width: 50%;">
        </a>
      
        
        
        

        
       <!------------------------------------------------------------------------------------------------------->

<!------------------------------------------------------------------------------------------------------>

      <!-- ---------------------------------------- -->
      <div class="row" style="margin-top: 150px;">
	<div class="col-md-offset-3 col-md-6" id="login-block">
		<div style="margin-bottom: 35px;">
			<h2 style="text-align: center;">Login Form</h2>
			<p style="text-align: center;">Login to access your account</p>
		</div>
		<form class="myform" action="commonlogin.php" method="post">
			<!-- <label><b>Username:</b></label><br>
			<input name="username" type="text" class="inputvalues" placeholder="Type your username" required/><br>
			<label><b>Password:</b></label><br>
			<input name="password" type="password" class="inputvalues" placeholder="Type your password" required/><br> -->
			<label class="label-text">
				Email ID: 
			</label>
			<input type="email" name="lemail" placeholder="Enter a valid Email" class="input-text" style="margin-left: 40px;" required>
			<br/>
			<label class="label-text">
				Password:
			</label>
            <input type="password" name="lpassword" placeholder="Enter your password" class="input-text" style="margin-left: 22px;" required>
			<input name="login" type="submit" id="login_btn" value="Login"/>
			<br />
			<!------------------------------------------------------>
			<p class="reg-text" style="margin-top: 20px;">Don't have an account?<a href="registercare.php"> Register</a></p>
			<p class="reg-text"><a href="forgetPasswordcare.php">Forget Password?</a></p>
		</form>
		
		<?php
		if(isset($_POST['login']))
		{
			// $username=$_POST['username'];
			// $password=$_POST['password'];
			$email =trim($_POST["lemail"]);
            $password =trim($_POST["lpassword"]);
			$encrypted_password = md5($password);
			
			//$query="select * from users WHERE username='$username' AND password='$encrypted_password'";
			$query="select * from userscare WHERE email ='$email' AND password='$encrypted_password'";
			$queryothera="select * from usersdoc WHERE email ='$email' AND password='$encrypted_password'";
            $queryotherb="select * from userspatient WHERE email ='$email' AND password='$encrypted_password'";

			$query_run = $con->query($query);	
			$queryothera_run = $con->query($queryothera);
            $queryotherb_run = $con->query($queryotherb);
			if($query_run->num_rows>0)
			{
				$row= $query_run->fetch_assoc();
				$_SESSION["care_id"]=$row['cid'];
				header('location:homepagecarenew.php');
			}
            if($queryothera_run->num_rows>0)
            {
                $row= $queryothera_run->fetch_assoc();
				$_SESSION["doctor_id"]=$row['did'];
                header('location:homepagedoc.php');
				

            }
            if($queryotherb_run->num_rows>0)
            {
                $row= $queryotherb_run->fetch_assoc();
                //$_SESSION['id']= $row['$pid'];
				//$pid = $_GET['patient_id'];
				//$_SESSION["id"]= $row["$pid"];
				//$stmt_edit = $db->prepare('SELECT  pid,pname FROM userspatient WHERE email ='$email' AND password='$encrypted_password'');
				//$stmt_edit->execute();
				//$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	 	        //extract($edit_row);
				 

				$_SESSION["patient_id"]=$row['pid'];
                header('location:homepagepat.php');
            }
			else
			{
				// invalid
				echo '<script type="text/javascript"> alert("Invalid credentials") </script>';
			}
			
		}
	
		?>  
		
	</div>
</div>
</div>
</body>
</html>
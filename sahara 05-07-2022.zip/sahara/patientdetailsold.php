<?php
ini_set( "display_errors", 0); 
	error_reporting( ~E_NOTICE );
	require_once 'dbconfig/config.php';
  require './vendor/autoload.php';
  use Aws\AwsClient;
  
	 if(isset($_GET['patient_id']) && !empty($_GET['patient_id']))
	 {
	 	$pid = $_GET['patient_id'];
	 	$stmt_edit = $db->prepare('SELECT  pid,pname, gender,age, image,username,date FROM userspatient WHERE pid =:uid');
	 	$stmt_edit->execute(array(':uid'=>$pid));
	 	$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	 	extract($edit_row);
       
		//  $stmt_edit1 = $db->prepare('SELECT  id,dname,spec,date FROM visited_list WHERE id =:uid');
	 	// $stmt_edit1->execute(array(':uid'=>$id1));
	 	// $edit_row1 = $stmt_edit1->fetch(PDO::FETCH_ASSOC);
	 	// extract($edit_row1);
	
	 }
	 else
	 {
	 	header("Location: homepagecare.php");
	 }
	 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sahara | Patient's Page</title>
<link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
 <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="jquery-1.11.3-jquery.min.js"></script>
<style>
	.nav-style{
  list-style-type: none !important;
  border-radius: 20px;
  background-color: #ffffff;
  padding: 10px 30px 10px 30px !important;
  border: solid 2px #92cdd5;
  margin-right: 10px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}

.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
.label-text{
      font-family: 'Raleway';
      font-size: 22px;
      font-weight: 400;
      text-align: left;
      border: black solid 1px;
      padding: 5px 20px;
      width: 200px;
      }
	  #login-block{    
      padding: 20px;
      border-radius: 5px;
      border: solid 1px #000000;
      background-color: #ffffff;
      }
      .myform{
      width: 50%;
      position: absolute;
      left: 80%;
      bottom: 75%;
      }
	  .heading{
        text-align: center;
        font-size: 24px;
        font-family: 'Raleway';
        text-transform: uppercase;
        margin-top: 10px;
        margin-bottom: 35px;
      }
      .sidenav {
        background: #92cdd5;
        text-align: center;
        color: black;
        position: fixed;
        left: 0;
        top: 0;
        width: 15%;
        min-height: calc(100vh - 0px);
        overflow: auto;
      }

      .sidenav a {
        /* padding: 20px 6px 25px 32px; */
        text-decoration: none;
        font-size: 20px;
        color: #000;
        display: block;
        text-align: left;
        margin-left: 20px;
        margin-top: 35px;
        font-family: 'Raleway';
      }

      .sidenav a:hover {
        color: #f1f1f1;
      }
</style>
</head>
<body>
	<nav class="navbar navbar-fixed-top navbar-expand-lg navbar-light" style="background-image: linear-gradient( to left,#92cdd5, #ffffff, #ffffff);"  nav-style>
        <a class="navbar-brand" href="#">
            <img src="imgs/SaharaLogo.png" alt="sahara-logo" style="width: 60%;">
        </a>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="indexmain.php">Home</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="aboutmain.php">About</a>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            Login
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="logincare.php">Caretaker</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logindoc.php">Doctor</a>
          </div>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Register
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
             
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registercare.php">Caretaker</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registerdoc.php">Doctor</a>
            </div>
          </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link" href="helpmain.php">Contact Us</a>
          </li>
      </ul>
    </div>
      </nav>
<!------------------------------------------ -->

<!---------------------------------------------------------------------------------------------------------->

<div class="container" style="margin-top: 120px; ">
<h3 class="heading">general information</h3>
<form method="" enctype="multipart/form-data" class="form-horizontal" style="border: solid 1px;border-radius:4px">
  
<table class="table table-responsive" style="margin-bottom: 0;">
  <tr>
 
    <td><label class="label-text" style="border: none;">Name:</label></td>
		<td class="label-text" style=" padding-top: 15px;border: 0;"><?php echo $pname; ?></td>
    <td><label class="label-text" style="border: none;">Patient ID:</label></td>
		<td class="label-text" style=" padding-top: 15px;border: 0;"><?php echo $pid; ?></td>
    </tr>
	<tr>
    <td><label class="label-text" style="border: none;">Age:</label></td>
    <td class="label-text" style=" padding-top: 15px;border: 0;"><?php echo $age; ?></td>
 
    <td><label class="label-text" style="border: none;">Gender:</label></td>
    <td class="label-text" style=" padding-top: 15px;border: 0;"><?php echo $gender; ?></td>
  </tr>	
</table>
	
</form>
</div>
<!-- --------------------------------------------------------------------------------->
<div class="container" style="margin-top: 20px;">
<div style="text-align:center;">
      <a class="btn btn-warning" href="departments.php" >Departments</a>
      <a class="btn btn-warning" href="doctor-page.php"> Doctor's page</a>
    </div>
	<div class="row" style="margin-top: 5em;"> 
		<div class="col-md-6">	
        <h2 class="heading" style="text-align: center;">Last Visited Doctors</h2>
        <table>
			<thead>
				<th class="label-text">Doctor Name</th>
				<th class="label-text">Speciality</th>
				<th class="label-text">Date</th>
			</thead>
</table>
<?php
		$sql=$db->prepare('SELECT id, dname, pname,spec, date FROM visited_list WHERE pname=? ORDER BY id DESC LIMIT 2');
	$sql->execute([$pname]);
	if($sql->rowCount()>0){
		while($row1=$sql->fetch(PDO::FETCH_ASSOC))
	{
		extract($row1);
		?>
		 <table>
			<tbody>
				<tr>
					<td class="label-text">
						<?php echo $dname;?>
					</td>
					<td class="label-text">
						<?php echo $spec;?>
					</td>
					<td class="label-text" style="text-align: center;">
						<?php echo $date;?>
					</td>
				</tr>
			</tbody>
		</table> 
		<?php
	}
} ?> 
</div>

    
 </div> 
</div>
  
    



</body>
</html>
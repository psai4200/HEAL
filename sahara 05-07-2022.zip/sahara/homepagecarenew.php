<?php
ob_start();
	session_start();
	require_once 'dbconfig/config.php';
  require_once 'vendor/autoload.php';
 
  use \Firebase\JWT\JWT;
  use GuzzleHttp\Client;
   
  
  if(isset($_SESSION['care_id']) && !empty($_SESSION['care_id']))
	 {
	 	$cid = $_SESSION['care_id'];
	 	//$stmt_edit = $db->prepare('SELECT  did,dname, gender,age, image,username,date FROM userspatient WHERE pid =:uid');
        $stmt_edit = $db->prepare('SELECT cid, cname FROM userscare WHERE cid =:uid');
	 	$stmt_edit->execute(array(':uid'=>$cid));
	 	$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	 	extract($edit_row);
       
		//  $stmt_edit1 = $db->prepare('SELECT  id,dname,spec,date FROM visited_list WHERE id =:uid');
	 	// $stmt_edit1->execute(array(':uid'=>$id1));
	 	// $edit_row1 = $stmt_edit1->fetch(PDO::FETCH_ASSOC);
	 	// extract($edit_row1);
	
	 }
	 else
	 {
	 	header("Location: homepagecarenew.php");
	 }
if(isset($_GET['delete_id']))
     {
         $id = $_GET['delete_id'];
         $stmt1 = $db->prepare('INSERT INTO visited_list SELECT * FROM appointment_list WHERE id=:uid');
         $stmt2 = $db->prepare('DELETE FROM appointment_list WHERE id =:uid');
         $db->beginTransaction();
        if ($stmt1->execute([':uid' => $id]) && $stmt2->execute([':uid' => $id])) 
        {
                $db->commit();
                header("Location:homepagecare.php");
        }
     //   header("Location: homepagecare.php");
     }
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<title>Sahara | Care Takers's Homepage</title>
<style>

  html, body {
    margin: 0;
    padding: 0;
    
    height:100vh;
  width: 100vw;
  overflow-x: hidden;
  background-image: url("website.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.nav-style{
  list-style-type: none !important;
  
  background-color:#ffffff;
  padding: 10px 30px 10px 30px !important;
  
  margin-right: 0px;
  margin-left: 25px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}


.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
.about-text{
    padding: 40px;
    padding-top: 0;
    font-size: 18px;
    text-align: justify;
    line-height: 1.5;
    font-family: 'Raleway';
} 
.heading{
	   text-align: center;
	   font-size: 24px;
	   font-family: 'Raleway';
	   text-transform: uppercase;
	   margin-top: -50px;
	   margin-bottom: 75px;
   }
   .heading1{
	   text-align: center;
	   font-size: 24px;
	   font-family: 'Raleway';
	   text-transform: uppercase;
	   margin-top: -50px;
	   margin-bottom: 60px;
   }
   .label-text{
      width: 50%;
      font-family: 'Raleway';
      font-size: 22px;
      font-weight: 400;
      text-align: left;
      border: black solid 1px;
      padding: 5px 20px;
      min-width: 160px;
      max-width: 160px;
      
   }
   .sidenav {
          background: #92cdd5;
          text-align: center;
          color: black;
          
          left: 0;
          width: 15%;
          min-height: calc(100vh - 0px);
          overflow: auto;
        }
        
        .sidenav a {
          /* padding: 20px 6px 25px 32px; */
          text-decoration: none;
          font-size: 20px;
          color: #000;
          display: block;
          text-align: left;
          margin-left: 20px;
          margin-top: 35px;
          font-family: 'Raleway';
        }
        
        .sidenav a:hover {
          color: #f1f1f1;
        }
        #logout_btn {
          margin-top: -220px;
          background-color: #c0392b;
          padding: 5px;
          color: white;
          width: 30%;
          text-align: center;
          font-size: 18px;
          font-weight: bold;
          margin-bottom: 20px;
          margin-left: 10px;
      }
      
    
      .myform{
      width: 50%;
      left: 80%;
      bottom: 75%;
      }
      .myformedit{
      width: 50%;
      position: absolute;
      left: 80%;
      bottom: 65%;
      }
      *{
    margin:0;
    padding:0;
    box-sizing: border-box;
    

  }
  .table-container{
    padding: 0 10%;
    margin: 40px auto 0;
  }
  .table{
    
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed !important;
    border: 1px solid #bdc3c7;
    transform: translate(0%,0%);
    box-shadow: 2px 2px 12px rgba(0,0,0,0.2), -1px -1px 8px rgba(0,0,0,0.2);
    border-radius: 10px 10px 0 0;
    overflow: hidden;
    background-color: #ffffff;
  
  }
  .table:nth-of-type(odd){
    background-color:#ddd;

  }
  
  .table1{
    width: 50%;
    border-collapse: collapse;
    table-layout: fixed !important;
    border: 1px solid #bdc3c7;
    transform: translate(0%,0%);
    box-shadow: 2px 2px 12px rgba(0,0,0,0.2), -1px -1px 8px rgba(0,0,0,0.2);
    border-radius: 10px 10px 0 0;
    overflow: hidden;
    background-color: #ffffff;
  
  }
  .table tr{
    transition: all .2s ease-in;
    cursor: pointer;
  }
  .table1 tr{
    transition: all .2s ease-in;
    cursor: pointer;
  }
  .table thead tr th{
    font-size: 14px;
    font-weight: medium;
    letter-spacing:0.35px;
    padding:12px;
    vertical-align: top;
    background-color: #16a085;
    color: #fff;
    font-weight:bold;
    
  }
  
  .table tbody tr td{
    font-size: 14px;
    letter-spacing:0.35px;
    font-weight: normal;
    
    padding:12px;
    text-align: left;
    vertical-align: top;
    border-bottom: 1px solid #dddddd;
    
    
  }
  
  .table1 thead tr th{
    font-size: 14px;
    font-weight: medium;
    letter-spacing:0.35px;
    padding:12px;
    vertical-align: top;
    background-color: #16a085;
    color: #fff;
    font-weight:bold;
  }
  
  .header{
    background-color: #16a085;
    color: #fff;
  }
  @media only screen and (max-width: 1024px){
    html, body {
    margin: 0;
    padding: 0;
    
    height:100vh;
  width: 100vw;
  overflow-x: hidden;
  background-image: url("websiteresize.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}

  
  }
@media only screen and (max-width: 768px){
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("websiteipad.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
  .nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  margin-top: -40px;
  
  margin-right: 0px;
  margin-left: 40px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}
  
  
}

  


  
      
</style>
</head>
<body>

    <nav class="navbar navbar-fixed-left navbar-expand-lg navbar-light" nav-style>
        <a class="navbar-brand" href="indexmain.php">
            <img src="SaharaLogo.png" alt="sahara-logo" style="width: 50%;">
        </a>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="homepagecare.php" style="margin-left:10px;" >Home</a>
          <a  class="nav-link" href="doctor-pagenew.php" style="margin-left:10px;" >Doctors</a>
          <a class="nav-link" href="homepagepatientnew.php" style="margin-left:10px;">Patients</a>
          <a class="nav-link" href="departmentsnew.php" style="margin-left:10px;">Department</a>
          <a class="nav-link" href="profilecare.php" style="margin-left:10px;">profile</a>
          
        </li>
        
        
        
        
          

        
      <form class="nav-item nav-style" action="homepagecarenew.php" method="post" style="margin-left:500px; margin-right:-50px; background-color: #ffffff; margin-top:-5px;">
				<button name="logout" type="submit" id="nav-link" class="btn btn-primary">Log Out</button>
			</form>
        
      </ul>
    </div>
      </nav>
       <!------------------------------------------------------------------------------------------------------->

<!------------------------------------------------------------------------------------------------------>
	
<div class="container" >
	<div class="row" style="align: center; margin-top: 0px;">
		<div style="margin-top: 40px">
    
			<h2 class="heading">Welcome Care Taker <?php echo "$cname"; ?></h2>
      <h2 class="heading">Care Taker ID : <?php echo "$cid"; ?></h2>
      
      <!--<a href="editprofiledoc.php"> Edit Profile</a>-->
      
		</div>

		


     
<div class="table-container" >
    <div>
       <h2 class="heading1" style="text-align: left;">Appointments</h2>
    </div>
    
    
   
  <table class="table" >
     <thead >
       <th >Patient ID</th>
       <th >Patient Name</th>
       <th >Doctor Name</th>
       <th >Date <!--<a class="btn btn-primary" href="calendar.php" style="left: 18.5%;top:15%">Check dates</a></th>-->
       <th >Time</th>
			
        <th >Details</th>
        <th >Start</th>
        <th >Action</th>
			</thead>
</table>

      <?php
        //	$stmt = $db->prepare('SELECT id, name, spec, image FROM generalmed ORDER BY id DESC');
        $stmt = $db->prepare('SELECT * FROM appointment_list WHERE cname=? ORDER BY id DESC');
	      $stmt->execute([$cname]);
        if($stmt->rowCount() > 0)
        {
	          while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	          {
		           extract($row);
		 ?>
  <table class="table">  
			<tbody>
				<tr>
        	<td >
						<?php echo $pid?>
					</td>
				
					
					<td >
						<?php echo $pname;?>
					</td>
          <td >
						<?php echo $dname;?>
					</td>
					<td  >
						<?php echo $date;?>
					</td>
					<td  >
						<?php echo $time;?>
					</td>
          
         
          <td >
					<a class="btn btn-warning" href="patientdetails.php?patient_id=<?php echo $row['pid']; ?>"> Details</a> 
						
					</td>
          <td >
					<a class="btn btn-warning" href="Start-Stop.php?patient_id=<?php echo $row['pid']; ?>"> Start</a> 
						
					</td>
          <td >
						<a class="btn btn-warning" href="?delete_id=<?php echo $row['id']; ?>"  onclick="return confirm('Are You Sure You Want To Delete This appointment?')">Delete</a>
          </td>
				</tr>
			</tbody>
		</table>  
		  
		<?php
	}	
}


	?>

</div>	
</div>
</div>



<div class="container" >
	<div class="row" style="margin-left: 0px; margin-top: 40px; margin-bottom: 60px;"> 
  <div class="table-container">
		<div>
			<h2 class="heading" style="text-align: left;">Last Visited Patients</h2>
		</div>	
    <?php
		$sql=$db->prepare('SELECT id, dname, pname,cname, date FROM visited_list  ORDER BY id DESC LIMIT 1');
	$sql->execute();
	if($sql->rowCount()>0){
		while($row1=$sql->fetch(PDO::FETCH_ASSOC))
	{
		extract($row1);
		?>
	
    <table class="table1" >
     <thead>
     <th >Doctor Name</th>
        <th >Patient Name</th>
        <th >Caretaker Name</th>
        <th >Date</th>
			</thead> 
		
			<tbody>
				<tr>
					<td >
						<?php echo $dname;?>
					</td>
					<td >
						<?php echo $pname;?>
					</td>
          <td >
						<?php echo $cname;?>
					</td>
					<td  style="text-align: center;">
						<?php echo $date;?>
					</td>
				</tr>
			</tbody>
		</table>
		
		<?php
	}
} ?> 
</div>     
 <!---------------------------------------------------------------------------------------------->

<!------------------------------------------------------------------------------------------------------>
<?php
			if(isset($_POST['logout']))
			{
				session_destroy();
				header('location:commonlogin.php');
			}
		?>
    
	

</div>
</div>

</body>
</html>
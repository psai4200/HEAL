<?php
ini_set( "display_errors", 0); 
require 'dbconfig/config.php';
if(isset($_GET['delete_id']))
{
  $stmt_select = $db->prepare('SELECT image FROM usersdoc WHERE did =:uid');
  $stmt_select->execute(array(':uid'=>$_GET['delete_id']));
  $imgRow=$stmt_select->fetch(PDO::FETCH_ASSOC);
  unlink("images/".$imgRow['image']);
  $stmt_delete = $db->prepare('DELETE FROM usersdoc WHERE did =:uid');
  $stmt_delete->bindParam(':uid',$_GET['delete_id']);
  $stmt_delete->execute();	
  header("Location: departments.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sahara | Psychology Doctors</title>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Montserrat+Alternates" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Noto+Sans+JP:300,400,500" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700" rel="stylesheet">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
  <style>
      body {
        font-family: "Lato", sans-serif;
      }
      
      .main {
        margin-left: 200px; /* Same as the width of the sidenav */
      }

      .heading{
        text-align: center;
        font-size: 24px;
        font-family: 'Raleway';
        text-transform: uppercase;
        margin-top: 10px;
        margin-bottom: 35px;
      }
    
      .nav-style{
        list-style-type: none !important;
        border-radius: 20px;
        background-color: #ffffff;
        padding: 10px 30px 10px 30px !important;
        border: solid 2px #92cdd5;
        margin-right: 10px;
        font-family: 'Raleway';
        font-size: 18px;
        letter-spacing: 1px;
      }

      .dropdown-item{
        padding: 0px 10px;
          font-size: 18px;
      }
      .dropdown-menu{
        padding: 15px;
        width: 250px;
        border-radius: 10px;
        box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
        background: #fff;
      }

      .doc-card{
        margin-left: 40px;
        margin-right: 40px;
        margin-bottom: 30px;
        width: 300px;
        height: 520px;
        border-radius: 10px;
        box-shadow: 0 4px 4px 0 rgb(0 0 0 / 25%);
        background-color: #fcfbfb;
        text-align: center;
      }
      .dept-img{
        width: 152px;
        height: 152px;
        margin: 20px 50px 20px 50px;
        border-radius: 100%;
      }
      .dept-name{
        font-family: Raleway;
        font-size: 36px;
        font-weight: bold;
        text-align: center;
      }
      .view-doc-btn{
        padding: 10px;
        font-size: 14px;
        position: relative;
        left: 65px;
        border-radius: 5px;
        border: none;
        background-color: #92cdd5;
      }

      .dept-info{
        text-align: center;
      }

      .page-header{
        font-family: 'Raleway';
        border-radius: 20px;
        font-size: 18px; 
        background-color:#a2d5dc; 
        text-align: center;
        padding-top: 5px;
      }
      .sidenav {
        /* height: 100%;
        width: 200px;
        position: fixed;
        z-index: 1;
        top: 0;
        left: 0;
        background-color: #111;
        overflow-x: hidden;
        padding-top: 40px; */
        background: #92cdd5;
        text-align: center;
        color: black;
        position: fixed;
        left: 0;
        top: 0;
        width: 15%;
        min-height: calc(100vh - 0px);
        overflow: auto;
      }
      
      .sidenav a {
        /* padding: 20px 6px 25px 32px; */
        text-decoration: none;
        font-size: 20px;
        color: #000;
        display: block;
        text-align: left;
        margin-left: 20px;
        margin-top: 35px;
        font-family: 'Raleway';
      }
      
      .sidenav a:hover {
        color: #f1f1f1;
      }
      </style>       
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-expand-lg navbar-light" style="background-image: linear-gradient( to left,#92cdd5, #ffffff, #ffffff);">
  <a class="navbar-brand" href="#">
      <img class="" src="imgs/SaharaLogo.png" alt="sahara-logo" style="width: 60%;">
  </a>

 
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="indexmain.php">Home</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="aboutmain.php">About</a>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            Login
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="logincare.php">Caretaker</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logindoc.php">Doctor</a>
          </div>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Register
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
             
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registercare.php">Caretaker</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registerdoc.php">Doctor</a>
            </div>
          </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link" href="helpmain.php">Contact Us</a>
          </li>
      </ul>
    </div>
</nav>
<!---------------------------------------------------------------------------------------------------------->
<div class="sidenav">
    <h4 style="margin-top: 55%;"></h4>
    <a href="homepagecare.php">Home</a>
    <a href="doctor-page.php">Doctors</a>
    <a href="homepagepatient.php">Patients</a>
    <a href="departments.php">Department</a>
    <a href="registerpatient.php">Patient Registration</a>
    <?php
	$stmt = $db->prepare('SELECT cid, cname, area, gender, image, address, username, email, password FROM userscare ORDER BY cid DESC');
	$stmt->execute();
if($stmt->rowCount() > 0)
{
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		extract($row);
		?>
      <a href="aboutcare.php">About</a>
      <a href="helpcare.php">Help</a>
		</div>       
		<?php
	}
}
else
{
	?> 
	<div class="col-xs-12">
		<div class="alert alert-warning">
			<span class="glyphicon glyphicon-info-sign"></span>&nbsp; No Data Found.
		</div>
	</div>
	<?php
}
?>
<!---------------------------------------------------------------------------------------------------------->
<div style="margin-top: 120px;margin-left: 150px;">
  <h2 class="heading">Psychology</h2>
</div>
<div class="container-fluid">
  <div class="row">
  <h1 class="heading" style="margin-left: 140px;">List of Members</h1><hr>
  </div>
<div class="row" style="margin-left: 200px;">
<?php
//	$stmt = $db->prepare('SELECT id, name, spec, image FROM generalmed ORDER BY id DESC');
$stmt = $db->prepare('SELECT did, dname, spec, image FROM usersdoc WHERE spec="psycho" ORDER BY did DESC');
$stmt->execute();
if($stmt->rowCount() > 0)
{
while($row=$stmt->fetch(PDO::FETCH_ASSOC))
{
  extract($row);
  ?>
  <div class="col-xs-3 doc-card">
  <h3 class="page-header">
    <?php echo $name;?>
  </h3>
  <img src="uploads/<?php echo $row['image']; ?>" class="img-rounded" width="250px" height="250px" style="margin: 10px;"/><hr>
  <h3 class="page-header" style="margin-top: 0;">
    <?php echo $spec;?>
  </h3>
  <p align="center">
  <span>
  <a class="btn btn-warning" href="?delete_id=<?php echo $row['did']; ?>" title="click for delete" onclick="return confirm('Are You Sure You Want To Delete This User?')"><span class="glyphicon glyphicon-trash"></span> Delete</a>
  </span>
  <a class="btn btn-warning" href="bookappoint.php" > Book appointment</a>
  </p>
</div>      
  <?php
}
}
else
{
?>
<div class="col-xs-12">
  <div class="alert alert-warning">
    <span class="glyphicon glyphicon-info-sign"></span>&nbsp; No Data Found.
  </div>
</div>
<?php
}
?>
</div>
</div>
</body>
</html>
<!-- <?php
	error_reporting( ~E_NOTICE );
	require_once 'dbconfig/config.php';
	
	 if(isset($_GET['edit_id']) && !empty($_GET['edit_id']))
	 {
	 	$id = $_GET['edit_id'];
	 	$stmt_edit = $db->prepare('SELECT username, address,name, email,password, image FROM userscare WHERE id =:uid');
	 	$stmt_edit->execute(array(':uid'=>$id));
	 	$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	 	extract($edit_row);
	 }
	 else
	 {
	 	header("Location: logincare.php");
	 }
	if(isset($_POST['btn_save_updates']))
	{
		$username = $_POST['user_name'];
		
		$address = $_POST['address'];	
		$name = $_POST['rname'];	
		$email = $_POST['email'];	
        $password =$_POST['rpassword'];
		$cpassword = $_POST['cpassword'];
		$imgFile = $_FILES['image']['name'];
		$tmp_dir = $_FILES['image']['tmp_name'];
		$imgSize = $_FILES['image']['size'];
		if($imgFile)
		{
			$upload_dir = 'uploads/';
			$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION));
			$valid_extensions = array('jpeg', 'jpg', 'png', 'gif');
			$image = rand(1000,1000000).".".$imgExt;
			if(in_array($imgExt, $valid_extensions))
			{			
				if($imgSize < 5000000)
				{
					unlink($upload_dir.$edit_row['image']);
					move_uploaded_file($tmp_dir,$upload_dir.$image);
				}
				else
				{
					$errMSG = "Sorry, Your File Is Too Large To Upload. It Should Be Less Than 5MB.";
				}
			}
			else
			{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF Extension Files Are Allowed.";		
			}	
		}
		else
		{
			$userprofile = $edit_row['image'];
		}
        if($password==$cpassword)
        {
            
            $encrypted_password = md5($password);
        }
        else
        {
            echo '<script type="text/javascript"> alert("Password and confirm password does not match!")</script>';	
        }
		if(!isset($errMSG))
		{
			$stmt = $db->prepare('UPDATE userscare SET username=:uname, address=:uad, name=:ufname, email=:uemail,password=:upassword, image=:upic WHERE id=:uid');
			$stmt->bindParam(':uname',$username);
			$stmt -> bindParam(':upassword',$encrypted_password);
			$stmt->bindParam(':uad',$address);
			$stmt->bindParam(':ufname',$name);
			$stmt->bindParam(':uemail',$email);
			$stmt->bindParam(':upic',$image);
			$stmt->bindParam(':uid',$id);
				
			if($stmt->execute()){
				?>
                <script>
				alert('Successfully Updated...');
				window.location.href='homepagecare.php';
				</script>
                <?php
			}
			else{
				$errMSG = "Sorry User Could Not Be Updated!";
			}
		}			
	}
?>  -->
<!DOCTYPE html>
<html>
<head>
<title>Sahara | Edit Profile</title>
<link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<style>
		.nav-style{
		  list-style-type: none !important;
		  border-radius: 20px;
		  background-color: #ffffff;
		  padding: 10px 30px 10px 30px !important;
		  border: solid 2px #92cdd5;
		  margin-right: 10px;
		  font-family: 'Raleway';
		  font-size: 18px;
		  letter-spacing: 1px;
		}
		
		.dropdown-item{
		  padding: 0px 10px;
			font-size: 18px;
		}
		.dropdown-menu{
		  padding: 15px;
		  width: 250px;
		  border-radius: 10px;
		  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
		  background: #fff;
		}
		#login-block{    
		padding: 10px 45px 20px 45px;
		border-radius: 5px;
		border: solid 1px #000000;
		background-color: #ffffff;
		}
		.myform{
				width: 100%;
		}
		.heading{
		text-align: center;
		font-size: 24px;
		font-family: 'Raleway';
		text-transform: uppercase;
		margin-top: 10px;
	}
	.label-text{
        font-family: 'Raleway';
        font-size: 18px;
        font-weight: 400;
        text-align: left;
    }
	.sidenav {
          background: #92cdd5;
          text-align: center;
          color: black;
          position: fixed;
          left: 0;
          top: 0;
          width: 15%;
          min-height: calc(100vh - 0px);
          overflow: auto;
        }
        
        .sidenav a {
          /* padding: 20px 6px 25px 32px; */
          text-decoration: none;
          font-size: 20px;
          color: #000;
          display: block;
          text-align: left;
          margin-left: 20px;
          margin-top: 35px;
          font-family: 'Raleway';
        }
        
        .sidenav a:hover {
          color: #f1f1f1;
        }
</style>
</head>
<body>
	<nav class="navbar navbar-fixed-top navbar-expand-lg navbar-light" style="background-image: linear-gradient( to left,#92cdd5, #ffffff, #ffffff);"  nav-style>
				<a class="navbar-brand" href="#">
					<img src="imgs/SaharaLogo.png" alt="sahara-logo" style="width: 60%;">
				</a>
			  
	<div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="indexmain.php">Home</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="aboutmain.php">About</a>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            Login
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
		  	<a class="dropdown-item" href="logincare.php">Caretaker</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logindoc.php">Doctor</a>
          </div>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Register
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="registerpatient.php">Patient</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registercare.php">Caretaker</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registerdoc.php">Doctor</a>
            </div>
          </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link" href="helpmain.php">Contact Us</a>
          </li>
      </ul>
    </div>
	</nav>

  <!---------------------------------------------------------------------------------------------------------->
  <div class="sidenav">
    <h4 style="margin-top: 55%;"></h4>
    <a href="homepagecare.php">Home</a>
    <a href="doctor-page.php">Doctors</a>
    <a href="homepagepatient.php">Patients</a>
    <a href="departments.php">Department</a>
    <a href="registerpatient.php">Patient Registration</a>
    <?php
	$stmt = $db->prepare('SELECT id, name, area, gender, image, address, username, email, password FROM userscare ORDER BY id DESC');
	$stmt->execute();
if($stmt->rowCount() > 0)
{
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		extract($row);
		?>
      <a href="aboutcare.php">About</a>
      <a href="helpcare.php">Help</a>
		</div>       
		<?php
	}
}
else
{
	?> 
	<div class="col-xs-12">
		<div class="alert alert-warning">
			<span class="glyphicon glyphicon-info-sign"></span>&nbsp; No Data Found.
		</div>
	</div>
	<?php
}
?>
  <!---------------------------------------------------------------------------------------------------------->
   
<!-- Main content -->
<div class="container-fluid h-100" style="width: 50%;margin-right: 18%;    margin-top: 8%">
		<div class="row">
		
		<!-- dashboard -->
			<div class="col-md-12">
				<div>
					<h2 class="heading">Edit Profile</h2>
					<a class="btn btn-success" href="homepagecare.php" style="position: relative; bottom: 40px;left: 88%;"><span class="glyphicon glyphicon-home"></span>&nbsp; Back</a>
				</div>
<form method="post" enctype="multipart/form-data" class="form-horizontal" style="border: solid 1px;border-radius:4px">
    <?php
	if(isset($errMSG)){
		?>
        <div class="alert alert-danger">
          <span class="glyphicon glyphicon-info-sign"></span> &nbsp; <?php echo $errMSG; ?>
        </div>
        <?php
	}
	?>
	<table class="table table-responsive">
    <tr>
    	<td><label class="control-label label-text">Username</label></td>
        <td><input class="form-control" type="text" name="user_name" value="<?php echo $username; ?>" required /></td>
    </tr>
 
	<tr>
    	<td><label class="control-label label-text">Address</label></td>
        <td><textarea class="form-control" rows="2" cols="140" name="address"  value="<?php echo $address; ?>" required></textarea></td>
    </tr>
	<tr>
    	<td><label class="control-label label-text">Name</label></td>
        <td><input class="form-control" type="text" name="rname" value="<?php echo $name; ?>" required /></td>
    </tr>
	<tr>
    	<td><label class="control-label label-text">Mail</label></td>
        <td><input class="form-control" type="email" name="email" value="<?php echo $email; ?>" required /></td>
    </tr>	
    <tr>
    	<td><label class="control-label label-text">Password</label></td>
        <td><input class="form-control" type="password" name="rpassword" value="<?php echo $password; ?>" required /></td>
    </tr>	
	<tr>
    	<td><label class="control-label label-text" style="text-align: left;">Confirm Password</label></td>
        <td><input class="form-control" type="password" name="cpassword" value="<?php echo $cpassword; ?>" required /></td>
    </tr>	
    	<tr><td><label class="control-label label-text" style="text-align: left;">Profile Picture</label></td>
        <td>
        	<p><img src="uploads/<?php echo $image; ?>" height="150" width="150" /></p>
        	<input class="input-group" type="file" name="image" accept="image/*" />
        </td>
    </tr>
    <tr>
        <td colspan="2" align="center">
		<button type="submit" name="btn_save_updates" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-save"></span>&nbsp; Save</button>
        <a class="btn btn-warning" href="homepagedoc.php"> <span class="glyphicon glyphicon-remove"></span>&nbsp; Cancel</a>
        </td>
    </tr>
    </table>
</form>
</div></div></div>
</body>
</html>
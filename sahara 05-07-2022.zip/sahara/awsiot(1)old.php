<?php
ini_set( "display_errors", 0); 
	error_reporting( ~E_NOTICE );
	require_once 'dbconfig/config.php';
  require './vendor/autoload.php';
  use Aws\AwsClient;
  class IotDataPlaneClient extends AwsClient {}

  
	 if(isset($_GET['patient_id']) && !empty($_GET['patient_id']))
	 {
	 	$pid = $_GET['patient_id'];
	 	$stmt_edit = $db->prepare('SELECT  pid,pname, gender,age, image,username,date FROM userspatient WHERE pid =:uid');
	 	$stmt_edit->execute(array(':uid'=>$pid));
	 	$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	 	extract($edit_row);
       
		//  $stmt_edit1 = $db->prepare('SELECT  id,dname,spec,date FROM visited_list WHERE id =:uid');
	 	// $stmt_edit1->execute(array(':uid'=>$id1));
	 	// $edit_row1 = $stmt_edit1->fetch(PDO::FETCH_ASSOC);
	 	// extract($edit_row1);
	
	 }
	 else
	 {
	 	//header("Location: homepagecare.php");
        header("Location: patientdetails.php");
	 }
echo $pid;
     $params = array(
        'credentials' => array(
            'key' => 'AKIAWN2L4TIXY6MBJJ7A',
            'secret' => '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',
          ),
        'region' => 'us-east-2',
        'version' => 'latest'
    );
    $client = new Aws\IotDataPlane\IotDataPlaneClient($params);
    $message = array( "status" => "start", "pid" => $pid);
        $result = $client->publish([
            'payload' =>'start '. $pid ,
            'qos' => 0, 
            'topic' => 'inPulse',
        ]);
        $result = $client->publish([
            'payload' => 'start '. $pid ,
           //here you'll send status : start , patient_id : <the patients id>
            'qos' =>0, // send 0
            'topic' => 'inTemp' // inTemp
        ]);
        $result = $client->publish([
          'payload' => 'start '. $pid ,
         //here you'll send status : start , patient_id : <the patients id>
          'qos' =>0, // send 0
          'topic' => 'inEcg' // inTemp
      ]);
    

    
	 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sahara | Patient's Page</title>
<link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
 <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="jquery-1.11.3-jquery.min.js"></script>
<style>
	.nav-style{
  list-style-type: none !important;
  border-radius: 20px;
  background-color: #ffffff;
  padding: 10px 30px 10px 30px !important;
  border: solid 2px #92cdd5;
  margin-right: 10px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}

.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
.label-text{
      font-family: 'Raleway';
      font-size: 22px;
      font-weight: 400;
      text-align: left;
      border: black solid 1px;
      padding: 5px 20px;
      
      }
	  #login-block{    
      padding: 20px;
      border-radius: 5px;
      border: solid 1px #000000;
      background-color: #ffffff;
      }
      .myform{
      width: 50%;
      position: absolute;
      left: 80%;
      bottom: 75%;
      }
	  .heading{
        text-align: center;
        font-size: 24px;
        font-family: 'Raleway';
        text-transform: uppercase;
        margin-top: 10px;
        margin-bottom: 35px;
      }
      .sidenav {
        background: #92cdd5;
        text-align: center;
        color: black;
        position: fixed;
        left: 0;
        top: 0;
        width: 15%;
        min-height: calc(100vh - 0px);
        overflow: auto;
      }

      .sidenav a {
        /* padding: 20px 6px 25px 32px; */
        text-decoration: none;
        font-size: 20px;
        color: #000;
        display: block;
        text-align: left;
        margin-left: 20px;
        margin-top: 35px;
        font-family: 'Raleway';
      }

      .sidenav a:hover {
        color: #f1f1f1;
      }
</style>
</head>
<body>
	<nav class="navbar navbar-fixed-top navbar-expand-lg navbar-light" style="background-image: linear-gradient( to left,#92cdd5, #ffffff, #ffffff);"  nav-style>
        <a class="navbar-brand" href="#">
            <img src="imgs/SaharaLogo.png" alt="sahara-logo" style="width: 60%;">
        </a>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="indexmain.php">Home</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="aboutmain.php">About</a>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            Login
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="logincare.php">Caretaker</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logindoc.php">Doctor</a>
          </div>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Register
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
             
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registercare.php">Caretaker</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registerdoc.php">Doctor</a>
            </div>
          </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link" href="helpmain.php">Contact Us</a>
          </li>
      </ul>
    </div>
      </nav>
<!------------------------------------------ -->

<!---------------------------------------------------------------------------------------------------------->


<!-- --------------------------------------------------------------------------------->

<div class="container" style="margin-top: 120px;">
  <div class="row" style="margin-left: 100px; margin-top: 50px;"> 
    <div class="col-md-6">
    <h3 class="heading" style="text-align: left;"> Diagnosis </h3>
    <a class="btn btn-success" href="patientdetails.php" style="position: relative; bottom: 40px;left: 60em;"><span class="glyphicon glyphicon-home"></span>&nbsp; Back</a>
    <p class="label-text" style="border: none;padding-left: 0;">
      Pulse: <span  class="label-text" style="border: none;" id="Pulse"></span>
      <br/><br/>
      Temperature: <span class="label-text" style="border: none;"  id="Temperature"></span>
      </p>
    <canvas id="ecg_canvas" width="500" height="160" style="background-color: black;"></canvas>
<?php
//	$stmt = $db->prepare('SELECT id, name, spec, image FROM generalmed ORDER BY id DESC');
$stmt = $db->prepare('SELECT * FROM userspatient');
	$stmt->execute();
if($stmt->rowCount() > 0)
{
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		extract($row);
		?>
   
    <?php
	}	
}


	?>
    </div>
    </div>
  
</div>

<!---------------------------------------------------------------------------------------------------------->
<script>
//const api_url = ' https://fitcy14lh4.execute-api.us-east-2.amazonaws.com/dev';//pulse 
const api_url = 'https://53sll1q0h5.execute-api.us-east-2.amazonaws.com/dev2';

async function getAPI(){
  var pid = "<?php echo $_GET['patient_id'];?>";
  //console.log(pid);
    const response = await fetch(api_url);
     data = await response.json();
    //const{Patient_id,ts,Pulse}=data;
   //var obj = JSON.parse(data);
   // console.log(data[0].ts);
   var pts = 0;

   console.log(pid) 
   for(i of data){
      if(i.Patient_id == pid ){  
        pts = i.ts;
        var demo = `${i.Pulse} Bpm`;
        document.getElementById('Pulse').textContent = demo;break;
        //console.log(demo);
     
    }
    else
    {
      var demo1 = "no ID exists";
      document.getElementById('ts').textContent = demo;
    }
   
    
}
}
getAPI();
setInterval(getAPI,5000);
//setTimeout(function (){
//getAPI();}, 10000)



const api_url1= 'https://0ck4xwoab7.execute-api.us-east-2.amazonaws.com/dev1';//temperature
async function getAPI1(){
  var pid = "<?php echo $_GET['patient_id'];?>";
  //console.log(pid);
    const response = await fetch(api_url1);
     data = await response.json();
    //const{Patient_id,ts,Temperature}=data;
    var pts1 = 0;
    //console.log(data)
   //var obj = JSON.parse(data);
    //console.log(data[0].Temperature);
    console.log(pid)
    for(i of data){
        
      if(i.Patient_id == pid ) {
        pts1 = i.ts;
        var demo = `${i.Temperature} C`;
        document.getElementById('Temperature').textContent = demo;break;
        //console.log(demo);
 
    }
    else{
      var demo1 = "no ID exists";
      document.getElementById('Temperature').textContent = demo1;
      
   }
  
    
}
}
getAPI1();
setInterval(getAPI1,5000);
</script>



<script>
async function getData(url) {
  try {
    const response = await fetch(url);
    var data = await response.json();
    return data;
  } catch (err) {
    alert("Unable to fetch ECG data")
  }
}

var data;
var canvas = document.getElementById("ecg_canvas");
var ctx = canvas.getContext("2d");
var w = canvas.width,
  h = canvas.height,
  speed = 1,
  scanBarWidth = 20,
  i = 0,
  color = '#00ff00';
var px = 0;
var opx = 0;
var py = h / 2;
var opy = py;
ctx.strokeStyle = color;
ctx.lineWidth = 3;
ctx.setTransform(1, 0, 0, -1, 0, h);


drawWave();



async function drawWave() {
  if (!data || data.length == 0 || (i + 1) >= data.length) {
    var pid = "<?php echo $_GET['patient_id'];?>";
    data = await getData('https://ai4o7m4ofb.execute-api.us-east-2.amazonaws.com/dev3/')
    console.log(pid)
    data=data.filter(d=>d.patient_id==pid)
    i=0;
  }
  px += speed;
  ctx.clearRect(px, 0, scanBarWidth, h);
  ctx.beginPath();
  ctx.moveTo(opx, opy);
  ctx.lineJoin = 'round';
  py = (data[i++]['ecg'] / 20 + 10);
  ctx.lineTo(px, py);
  ctx.stroke();
  opx = px;
  opy = py;
  if (opx > w) {
    px = opx = -speed;
  }
  requestAnimationFrame(drawWave);
}





  </script>
<!--<script>
/*const api_url3 = 'https://ai4o7m4ofb.execute-api.us-east-2.amazonaws.com/dev3';//ecg
const xlabels = [];
const ytemps = [];

chartit();
async function chartit(){
await getAPI3();
setInterval(getAPI3,100);
const ctx = document.getElementById('myChart').getContext('2d');
//ctx.canvas.width = 200;
//ctx.canvas.height = 200;
const myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: xlabels,
        datasets: [{
            label: 'ECG',
            data: ytemps,
            backgroundColor:'rgba(255, 99, 132, 0.2)',
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 1
        }]
    },
    options: {
    maintainAspectRatio: false,
    //aspectRatio: 1,
    responsive:true
    //resizeDelay: 200
    }
    
});
}

console.log("hello");
//const api_url3 = 'https://ai4o7m4ofb.execute-api.us-east-2.amazonaws.com/dev3';//ecg
/*async function getAPI3(){
  var pid = 1; 
  console.log(pid);
    const response = await fetch(api_url3);
     data = await response.json();
    const{Patient_id,ts,ecg}=data;
   //var obj = JSON.parse(data);
   // console.log(data[0].ts);
   var pts = 0;

    for(i of data){
      if(i.Patient_id == pid && i.ts > pts)
     {  pts = i.ts;
        var demo = `${i.ecg}`;
        //var demo1 = `${i.ts}`;
        var myDate = new Date(i.ts);
        var date = myDate.toLocaleString()
        //document.getElementById('ecg').textContent = demo;
        ytemps.push(demo);
        //document.getElementById('date').textContent= date;
        xlabels.push(date);
        //document.getElementById('ts1').textContent = demo1;
        
        
     
    }
    console.log(data);
    //else
   // {
     // var demo1 = "no ID exists";
     // document.getElementById('ts').textContent = " ";
   // }
   
    
}
}
//getAPI3();
//setInterval(getAPI3,100);*/




/*const api_url3 = 'https://ai4o7m4ofb.execute-api.us-east-2.amazonaws.com/dev3';//ecg
async function getAPI3(){
  var pid = "1";
  console.log(pid);
    const response = await fetch(api_url3);
     data = await response.json();
    const{Patient_id,ts,ecg}=data;
   //var obj = JSON.parse(data);
   // console.log(data[0].ts);
   var pts = 0;

    for(i of data){
      if(i.Patient_id == pid && i.ts > pts)
     {  pts = i.ts;
        var demo = `${i.ecg}`;
        //var demo1 = `${i.ts}`;
        var myDate = new Date(i.ts);
        var date = myDate.toLocaleString()
        document.getElementById('ecg').textContent = demo;
        document.getElementById('date').textContent= date;
        //document.getElementById('ts1').textContent = demo1;
        
        
     
    }
    console.log(data);
    //else
   // {
     // var demo1 = "no ID exists";
     // document.getElementById('ts').textContent = " ";
   // }
   
    
}
}
getAPI3();
//setInterval(getAPI3,100);*/

   </script>-->
 
</body>
</html>


    

    




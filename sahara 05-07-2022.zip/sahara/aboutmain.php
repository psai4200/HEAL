<!-- the main about page -->
<?php
  require 'vendor/autoload.php';
  require 'dbconfig/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<style>
.nav-style{
  list-style-type: none !important;
  border-radius: 20px;
  background-color: #ffffff;
  padding: 10px 30px 10px 30px !important;
  border: solid 2px #92cdd5;
  margin-right: 10px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}

.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
.about-text{
    padding: 40px;
    padding-top: 0;
    font-size: 18px;
    text-align: justify;
    line-height: 1.5;
    font-family: 'Raleway';
} 
.heading{
	   text-align: center;
	   font-size: 24px;
	   font-family: 'Raleway';
	   text-transform: uppercase;
	   margin-top: 15px;
	   margin-bottom: 25px;
   }
</style>
</head>
<body>
    <nav class="navbar fixed-top navbar-expand-lg navbar-light" style="background-image: linear-gradient( to left,#92cdd5, #ffffff, #ffffff);"  nav-style>
        <a class="navbar-brand" href="#">
            <img src="imgs/SaharaLogo.png" alt="sahara-logo" style="width: 60%;">
        </a>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="indexmain.php">Home</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="aboutmain.php">About</a>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            Login
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="logincare.php">Caretaker</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logindoc.php">Doctor</a>
          </div>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Register
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
             
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registercare.php">Caretaker</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registerdoc.php">Doctor</a>
            </div>
          </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link" href="helpmain.php">Contact Us</a>
          </li>
      </ul>
    </div>
      </nav>
<!-- --------------------------------------------------------------------------------------------------------------- -->
      <div class="container">
          <h2 class="heading">About</h2>
          <div class="about-text">
            <p>When the pandemic first hit, virtually every hospital in the country told people “only come to the hospital if you have COVID.” That had an immediate and measurable impact on demand for acute care. The volume of non-COVID-19 hospital patients dropped precipitously.
              With acute care telemedicine, you can do things at a reduced cost as a hospital, while also trying to leverage and maximize your best clinicians across more than one site. And everywhere, you have to think about windshield time, hallway time, drive time, all that is time that you could be spending with a patient. In fact, most physicians would prefer to be spending that time with a patient versus running out of their house at 2:00 AM to the hospital, or running down the hallway between floors. By eliminating this wasted time, providers can be more efficient.
            </p>
          </div>
          <div class="about-text">
              <p style="    margin-bottom: 30px;">
                Say hello to SAHARA, your real-time medical assistant. SAHARA is a telemedicine system crafted for the people of rural India. This device also known as Systematic Analysis of Health-vitals in an Automated Real-time Atmosphere.
              </p>
              <p>SAHARA's vision is to transform remote healthcare by enabling patients to have increased access to the highest quality care via a technology-enabled platform.
                We partner with healthcare organizations to bring clinicians and patients together using innovative technologies to improve clinical care and patient outcomes in a measurable way.
              </p>
          </div>
      </div>
</body>
</html>
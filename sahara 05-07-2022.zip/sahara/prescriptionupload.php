<?php

ob_start();
	session_start();
	require_once 'dbconfig/config.php';
  require_once 'vendor/autoload.php';
 
  use \Firebase\JWT\JWT;
  use GuzzleHttp\Client;
  if(isset($_GET['pr_id']) && !empty($_GET['pr_id']))
	 {
	 	$id = $_GET['pr_id'];
	 	$stmt_edit = $db->prepare('SELECT id, image FROM visited_list WHERE id =:uid');
	 	$stmt_edit->execute(array(':uid'=>$id));
	 	$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	 	extract($edit_row);
       
	 }
	 

?>  
	
<!DOCTYPE html>
<html>
<head>
<title>Sahara | Prescription Upload </title>
<link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat+Alternates" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans+JP:300,400,500" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700" rel="stylesheet">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<script type="text/javascript">
function PreviewImage() {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("image").files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("uploadPreview").src = oFREvent.target.result;
        };
    };
    

</script>
<style>
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("website.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  
}
#login-block{    
	   padding: 10px 45px 20px 45px;
	   border-radius: 5px;
	   border: solid 1px #000000;
	   background-color: #ffffff;
   }


.nav-style{
  list-style-type: none !important;
  
  background-color:#ffffff;
  padding: 10px 30px 10px 30px !important;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}


.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
.about-text{
    padding: 40px;
    padding-top: 0;
    font-size: 18px;
    text-align: justify;
    line-height: 1.5;
    font-family: 'Raleway';
} 
.heading{
	   text-align: center;
	   font-size: 24px;
	   font-family: 'Raleway';
	   text-transform: uppercase;
	   margin-top: -50px;
	   margin-bottom: 75px;
   }
   .heading1{
	   text-align: center;
	   font-size: 24px;
	   font-family: 'Raleway';
	   text-transform: uppercase;
	   margin-top: -50px;
	   margin-bottom: 60px;
   }
   .label-text{
    
	   font-family: 'Raleway';
	   font-size: 22px;
	   font-weight: 400;
	   text-align: left;
   }

      
   
      
   
  
        
      
    
      .myform{
      width: 100%;
      left: 80%;
      bottom: 75%;
      }
      .myformedit{
      width: 50%;
      position: absolute;
      left: 80%;
      bottom: 65%;
      }
      *{
    margin:0;
    padding:0;
    box-sizing: border-box;
    

  }
  .container{
      width 100%;
      height 100vh;
      display: flex;
     
      align-items:center;
      justify-content: center;
      margin-right: 150px;
      margin-left: 150px;

  }
  
@media only screen and (max-width: 1024px){
    html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  width: 100%;
  overflow-x: hidden;
  background-image: url("websiteresize.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  
}
.nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  margin-top: 0px;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}
.row{
  margin-right:300px;
}
}
@media only screen and (max-width: 768px){
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("websiteipad.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
  .nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  margin-top: 0px;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}
.row{
   width: 50%;
}

  
  
}
  
      
</style>
</head>
<body>

        <a class="navbar-brand" href="indexmain1.php">
            <img src="SaharaLogo.png" alt="sahara-logo" style="width: 50%;">
        </a>
      
        
      </nav>
       <!------------------------------------------------------------------------------------------------------->
       <form class="myform" action="prescriptionupload.php?pr_id=<?php echo $id; ?>" method="post" enctype="multipart/form-data" >
       <span style="margin-left: 5%;">
			<img id="uploadPreview" src="imgs/patient.png" class="avatar"/>
			<input type="file" id="image" name="image" accept=".jpg,.jpeg,.png" onchange="PreviewImage();" class="label-text" style="display: inline;margin-left: 20px;"/>
		</span>
		<br>
        
		<input  class="btn btn-primary" name="submit_btn" type="submit" id="signup_btn" value="Upload"style="margin: 0 auto;display: block;margin-top: 15px; width: 15%;"/><br>
		
		</form>

        <?php
			if(isset($_POST['submit_btn']))
			{
                $img_name = $_FILES['image']['name'];
				        $img_size =$_FILES['image']['size'];
			          $img_tmp =$_FILES['image']['tmp_name'];
				
				
				 $directory = 'uploads/';
				 $target_file = $directory.$img_name;
         
         $query= "SELECT * FROM visited_list WHERE id= $id";
					$query_run = $con->query($query);	
					
					
					if(file_exists($target_file))
					{
						echo '<script type="text/javascript"> alert("Image file already exists.. Try another image file") </script>';
					}
					
					else if($img_size>2097152)
					{
						echo '<script type="text/javascript"> alert("Image file size larger than 2 MB.. Try another image file") </script>';
					}

					
					else
					{
						move_uploaded_file($img_tmp,$target_file); 	
						//$query= "insert into usersdoc values('','$rname',  '$remail','$encrypted_password','$rmobile','$target_file')";
						$query= "UPDATE visited_list SET image='$target_file' WHERE id= $id";
						$query_run = $con->query($query);	
						
						
						if($query_run)
						{
						 	echo '<script type="text/javascript"> alert("Prescription uploaded") </script>';
						 }
						else
						{
						 	echo '<script type="text/javascript"> alert("Error!") </script>';
						 }
					}	
					
					
				}
				
			
		?>         
      
</body>
</html>
<!-- the main page for the website -->
<?php
ini_set( "display_errors", 0); 
	require 'dbconfig/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sahara | Home Page</title>
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@100;300;400;500&display=swap" rel="stylesheet">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<style>
.nav-style{
  list-style-type: none !important;
  border-radius: 20px;
  background-color: #ffffff;
  padding: 10px 30px 10px 30px !important;
  border: solid 2px #92cdd5;
  margin-right: 10px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}

.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
.heromodule{
    /* background: linear-gradient(180deg, rgba(181,237,251,1) 0%, rgba(251,255,252,1) 39%, rgba(255,249,194,1) 100%); */
    position: relative;
}
.aligntext{
    text-align: center;
}
.hero-text{
  font-family: 'Raleway';
  color: #2c5e8a;
  font-weight: 600;
  text-transform: capitalize;
  padding: 20px 0 0;
  font-size: 55px;
  text-align: left;
  line-height: 1.2;
}
.hero-subtext{
  font-family: 'Noto Sans JP', sans-serif;
  font-size: 20px;
  text-align: left;
  color: #6a6a77;
}
.visit-text{
  font-family: 'Noto Sans JP', sans-serif;
  font-size: 22px;
  text-align: left;
  color: #6a6a77;
  padding-top: 10px;
}
.visit-head{
  font-size: 40px;
  font-weight: 500;
  color: #3c6890;
}
.register-btn{
  font-size: 26px;
  padding: 10px;
  margin: 10px 0;
  margin-right: 5px;
  background-color: #ffce1e;
  border-color: #ffce1e;
  font-weight: 600;
  width: 30%;
}
</style>
</head>
<body>
    <nav class="navbar navbar-fixed-top navbar-expand-lg navbar-light" style="background-image: linear-gradient( to left,#92cdd5, #ffffff, #ffffff);"  nav-style>
        <a class="navbar-brand" href="#">
            <img src="imgs/SaharaLogo.png" alt="sahara-logo" style="width: 60%;">
        </a>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="indexmain.php">Home</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="aboutmain.php">About</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="commonlogin.php">Login</a>
        </li>
        
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Register
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registercare.php">Caretaker</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registerdoc.php">Doctor</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registerpatientmain.php">Patient</a>
            </div>
          </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link" href="helpmain.php">Contact Us</a>
          </li>
      </ul>
    </div>
      </nav>
      <!-- ---------------------------------------- -->
      <div class=" heromodule">

        <div class="container" style="margin-top: 100px;padding: 0;">
          <div style="padding-top: 30px;">
            <h1 class="aligntext hero-text">Meet Sahara, <br/> <span style="font-size: 45px; color: #6598c5;">your personalised health assistant.</span></h1>
            <!-- <p class="aligntext hero-subtext">(Systematic Analysis of Health-vitals in an Automated Real-time Atmosphere)</p> -->
          </div>
          <div class="row" style="position: relative;">
            <div class="col-md-6" style="margin-top: 5%;"> 
              <!-- <img src="imgs/Hands - Pinches.png" style="position: absolute; left: 140%;bottom: 95%; width: 55%;"/> -->
              <h2 class="visit-head">Help people from the comforts of your house</h2>
              <p class="visit-text">New Frontline Worker? Register today</p>
              <button class="btn btn-warning btn-lg register-btn"><a href="registerdoc.php" style="color: #fff; text-decoration: none;">Doctor</a></button>
              <button class="btn btn-warning btn-lg register-btn"><a href="registercare.php" style="color: #fff; text-decoration: none;">Caretaker</a></button>
            </div>
            <div class="col-md-6">
              <img src="imgs/Hands - Pinches.png" style="position: absolute; left: 50%; width: 55%; top: -90px;"/>
              <img src="imgs/docHelp.png" style="position: relative; left: 30%; top:45px"/>
            </div>
          </div>
          <!-- <img src="imgs/Humaaans - Space.png" style="width: 15%;    position: relative;right: 11%;"/> -->
        </div>
      </div>
</body>
</html>
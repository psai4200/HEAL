<?php
ini_set( "display_errors", 0); 
	error_reporting( ~E_NOTICE );
	require_once 'dbconfig/config.php';
  require './vendor/autoload.php';
  use \Firebase\JWT\JWT;
  use GuzzleHttp\Client;
   
  define('ZOOM_API_KEY', 'DpVgvQUtSKaCpN-E0Qcy4A');
  define('ZOOM_SECRET_KEY', 'kjS5ksKhu9HUZya1JeUMgoB49olvp6uewVb9');
  
  function getZoomAccessToken() {
      $key = ZOOM_SECRET_KEY;
      $payload = array(
          "iss" => ZOOM_API_KEY,
          'exp' => time() + 3600,
      );
      return JWT::encode($payload, $key);    
  }
  use Aws\AwsClient;
  
	 if(isset($_GET['patient_id']) && !empty($_GET['patient_id']))
	 {
	 	$pid = $_GET['patient_id'];
	 	$stmt_edit = $db->prepare('SELECT  pid,pname, gender,age, image,username,date FROM userspatient WHERE pid =:uid');
	 	$stmt_edit->execute(array(':uid'=>$pid));
	 	$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	 	extract($edit_row);
       
		//  $stmt_edit1 = $db->prepare('SELECT  id,dname,spec,date FROM visited_list WHERE id =:uid');
	 	// $stmt_edit1->execute(array(':uid'=>$id1));
	 	// $edit_row1 = $stmt_edit1->fetch(PDO::FETCH_ASSOC);
	 	// extract($edit_row1);
	
	 }
	 else
	 {
	 	header("Location: homepagecare.php");
	 }
?>

<!DOCTYPE html>
<html>
<head>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sahara | Home Page</title>
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
 <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="jquery-1.11.3-jquery.min.js"></script>
<style>
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("website.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  }
  #login-block{    
      padding: 20px;
      border-radius: 5px;
      border: solid 1px #000000;
      background-color: #ffffff;
      }
      .myform{
      width: 50%;
      position: absolute;
      left: 80%;
      bottom: 75%;
      }
	  .heading{
        text-align: center;
        font-size: 24px;
        font-family: 'Raleway';
        text-transform: uppercase;
        margin-top: 10px;
        margin-bottom: 35px;
      }
  
  .nav-style{
  list-style-type: none !important;
  
  background-color:#ffffff;
  padding: 10px 30px 10px 30px !important;
  
  margin-right: 0px;
  margin-left:1400px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}

.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
.heromodule{
    /* background: linear-gradient(180deg, rgba(181,237,251,1) 0%, rgba(251,255,252,1) 39%, rgba(255,249,194,1) 100%); */
    position: absolute;
    margin-left: 350px;
}
.aligntext{
    text-align: center;
}
.hero-text{
  font-family: 'Raleway';
  color: #2c5e8a;
  font-weight: 600;
  text-transform: capitalize;
  padding: 20px 0 0;
  font-size: 55px;
  text-align: left;
  line-height: 1.2;
}
#logout_btn {
          margin-top: -220px;
          background-color: #c0392b;
          padding: 5px;
          color: white;
          width: 30%;
          text-align: center;
          font-size: 18px;
          font-weight: bold;
          margin-bottom: 20px;
          margin-left: 10px;
      }
.hero-subtext{
  font-family: 'Noto Sans JP', sans-serif;
  font-size: 20px;
  text-align: left;
  color: #6a6a77;
}
.visit-text{
  font-family: 'Noto Sans JP', sans-serif;
  font-size: 22px;
  text-align: left;
  color: #6a6a77;
  padding-top: 10px;
}
.visit-head{
  font-size: 40px;
  font-weight: 500;
  color: #3c6890;
}
.register-btn{
  font-size: 26px;
  padding: 10px;
  margin: 10px 0;
  margin-right: 5px;
  background-color: #ffce1e;
  border-color: #ffce1e;
  font-weight: 600;
  width: 30%;
}
  
  
@media only screen and (max-width: 1024px){
    html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  width: 100%;
  overflow-x: hidden;
  background-image: url("websiteresize.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  
}
}
.heromodule{
 margin-left: 200px;
}
.nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  
  
  margin-right: 50px;
  margin-left: 900px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}


.table-container{
    padding: 0 10%;
    margin: 40px auto 0;
  }
.table{
    
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed !important;
    border: 1px solid #bdc3c7;
    transform: translate(0%,0%);
    box-shadow: 2px 2px 12px rgba(0,0,0,0.2), -1px -1px 8px rgba(0,0,0,0.2);
    border-radius: 10px 10px 0 0;
    overflow: hidden;
    background-color: #ffffff;
  
  }
  .table:nth-of-type(odd){
    background-color:#ddd;

  }
  
  .table1{
    width: 50%;
    border-collapse: collapse;
    table-layout: fixed !important;
    border: 1px solid #bdc3c7;
    transform: translate(0%,0%);
    box-shadow: 2px 2px 12px rgba(0,0,0,0.2), -1px -1px 8px rgba(0,0,0,0.2);
    border-radius: 10px 10px 0 0;
    overflow: hidden;
    background-color: #ffffff;
  
  }
  .table tr{
    transition: all .2s ease-in;
    cursor: pointer;
  }
  .table1 tr{
    transition: all .2s ease-in;
    cursor: pointer;
  }
  .table thead tr th{
    font-size: 14px;
    font-weight: medium;
    letter-spacing:0.35px;
    padding:12px;
    vertical-align: top;
    background-color: #16a085;
    color: #fff;
    font-weight:bold;
    
  }
  
  .table tbody tr td{
    font-size: 14px;
    letter-spacing:0.35px;
    font-weight: normal;
    
    padding:12px;
    text-align: left;
    vertical-align: top;
    border-bottom: 1px solid #dddddd;
    
    
  }
  
  .table1 thead tr th{
    font-size: 14px;
    font-weight: medium;
    letter-spacing:0.35px;
    padding:12px;
    vertical-align: top;
    background-color: #16a085;
    color: #fff;
    font-weight:bold;
  }
  
  .header{
    background-color: #16a085;
    color: #fff;
  }

  @media only screen and (max-width: 1024px){
    html, body {
    margin: 0;
    padding: 0;
    
    height:100vh;
  width: 100vw;
  overflow-x: hidden;
  background-image: url("websiteresize.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}

  
  }
@media only screen and (max-width: 768px){
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("websiteipad.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
  .nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  margin-top: -40px;
  
  margin-right: 0px;
  margin-left: 40px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}
  
}


  
  
@media only screen and (max-width: 768px){
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("websiteipad.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.heromodule{
 margin-left: 10px;
 margin-top: 140px;
 
 align: center;
}
  .nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  
  
  margin-right: 50px;
  margin-left: 625px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}
.navbar-brand{
 
}
}









      
</style>
</head>
<body>

    
  <nav  nav-style>
        <a class="navbar-brand" href="indexmain1.php">
            <img src="SaharaLogo.png" alt="sahara-logo" style="width: 50%;">
        </a>
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="homepagecare.php" style="margin-left:10px;" >Home</a>
          <a  class="nav-link" href="doctor-pagenew.php" style="margin-left:10px;" >Doctors</a>
          <a class="nav-link" href="homepagepatientnew.php" style="margin-left:10px;">Patients</a>
          <a class="nav-link" href="departmentsnew.php" style="margin-left:10px;">Department</a>
          <a class="nav-link" href="profilecare.php" style="margin-left:10px;">profile</a>
          
        </li>
        <form class="nav-item nav-style" action="homepagecarenew.php" method="post" style="margin-left:1370px; margin-right:-50px; background-color: #ffffff; margin-top:-50px;">
				<button name="logout" type="submit" id="nav-link" class="btn btn-primary">Log Out</button>
			</form>

        
       <!------------------------------------------------------------------------------------------------------->

<!------------------------------------------------------------------------------------------------------>

      <!-- ---------------------------------------- -->
      <div class="container" style="margin-top: 60px; ">
<h3 class="heading">Consultation</h3>
<p class="label-text zoom-link-p" >
      <?php 
                     function createZoomMeeting() {
                        $client = new Client([
                            // Base URI is used with relative requests
                            'base_uri' => 'https://api.zoom.us',
                        ]);
                     
                        $response = $client->request('POST', '/v2/users/me/meetings', [
                            "headers" => [
                                "Authorization" => "Bearer " . getZoomAccessToken()
                            ],
                            'json' => [
                                "topic" => "Doctor Appointment",
                                "type" => 2,
                                "start_time" => "2021-01-30T20:30:00",
                                "duration" => "30", // 30 mins
                                "password" => "123456"
                            ],
                        ]);
                     
                        $data = json_decode($response->getBody());
                        // echo "Join URL: ". $data->join_url ."<a href='". $data->join_url ."'>Open URL</a>";
                        // echo "<br>";
                        // echo "Meeting Password: ". $data->password;
                        // echo "<br>";
                        echo "<a href='". $data->join_url ."' class='btn btn-warning' target='_blank'>Start consulting</a>";
                    }
                     
                    createZoomMeeting();
                     ?>
                    </p>
<form method="" enctype="multipart/form-data" class="form-horizontal" style="border: solid 1px;border-radius:4px">
  
<table class="table" style="margin-bottom: 0;">
  <tr>
 
    <td><label  style="border: none;">Name:</label></td>
		<td  style=" padding-top: 15px;border: 0;"><?php echo $pname; ?></td>
    <td><label  style="border: none;">Patient ID:</label></td>
		<td  style=" padding-top: 15px;border: 0;"><?php echo $pid; ?></td>
    </tr>
	<tr>
    <td><label  style="border: none;">Age:</label></td>
    <td  style=" padding-top: 15px;border: 0;"><?php echo $age; ?></td>
 
    <td><label  style="border: none;">Gender:</label></td>
    <td  style=" padding-top: 15px;border: 0;"><?php echo $gender; ?></td>
  </tr>	
</table>
	
</form>
</div>
<!-- --------------------------------------------------------------------------------->
<div class="container" style="margin-top: 20px;">
<div style="text-align:center;">
      <a class="btn btn-warning" href="departments.php" >Departments</a>
      <a class="btn btn-warning" href="doctor-page.php"> Doctor's page</a>
    </div>
	<div class="row" style="margin-top: 5em;"> 
		<div class="col-md-6">	
        <h2 class="heading" style="text-align: center;">Last Visited Doctors</h2>
        <table class="table">
			<thead>
				<th class="label-text">Doctor Name</th>
				<th class="label-text">Speciality</th>
				<th class="label-text">Date</th>
			</thead>
</table>
<?php
		$sql=$db->prepare('SELECT id, dname, pname,spec, date FROM visited_list WHERE pname=? ORDER BY id DESC LIMIT 2');
	$sql->execute([$pname]);
	if($sql->rowCount()>0){
		while($row1=$sql->fetch(PDO::FETCH_ASSOC))
	{
		extract($row1);
		?>
		 <table class="table">
			<tbody>
				<tr>
					<td class="label-text">
						<?php echo $dname;?>
					</td>
					<td class="label-text">
						<?php echo $spec;?>
					</td>
					<td class="label-text" style="text-align: center;">
						<?php echo $date;?>
					</td>
				</tr>
			</tbody>
		</table> 
		<?php
	}
} ?> 
</div>


<div class="col-md-6">
    <h3 class="heading" style="text-align: center;">Diagnosis </h3>
<?php
//	$stmt = $db->prepare('SELECT id, name, spec, image FROM generalmed ORDER BY id DESC');
$stmt = $db->prepare('SELECT * FROM userspatient WHERE pid=? ');
$stmt->execute([$pid]);
if($stmt->rowCount() > 0)
{
	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
	{
		extract($row);
?>
    <a class="btn btn-warning" href="awsiot(1).php?patient_id=<?php echo $row['pid']; ?>" style="text-align: center;background-color: #388638;
      border-color: green;position: absolute;left: 17em;"> Current Vitals</a> 
   
<?php
	}	
}
?>
  
  </div>

    
 </div> 
</div>
</body>
</html>
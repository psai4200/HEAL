<?php
ob_start();
require_once 'dbconfig/config.php';
    if(isset($_POST["forget-password"])){
        if(!empty($_POST["user-email"])){
            $email = trim($_POST["user-email"]);
        } else {
            $error_message = "<li>Email is required</li>";
        }
        if(empty($error_message)){
            $query = $db->prepare("SELECT cname, email FROM userscare WHERE email =?");
            $query->execute(array($email));
            $user = $query->fetchAll(PDO::FETCH_ASSOC);
        }
        if(!empty($user)){
//            $msg='yes';
//            echo "<script type='text/javascript'>alert('$msg');</script>";
           require_once ("forget-password-mailcare.php");
        } else {
            $error_message = 'No Email Found';
        }
    }
?> 
<!DOCTYPE html>
<html>
<head>
<title>Sahara | Forget Password</title>
<link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Noto+Sans+JP:300,400,500" rel="stylesheet">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
        <link href="style.css" rel="stylesheet">
<style>
    #login-block{
		padding: 30px 65px 65px 60px;
		border-radius: 5px;
		border: solid 1px #000000;
		background-color: #ffffff;
	}
    .label-text{
        font-family: 'Raleway';
        font-size: 24px;
        font-weight: 400;
        text-align: left;
    }
    .input-text{
		margin-left: 20px;
		width: 60%;
	}
    #forget-password{
		text-align: center;
		border-radius: 25px;
		border: solid 0 #000000;
		background-color: #5796e0;
		width: 50%;
		position: relative;
		margin-top: 20px;
		font-family: 'Raleway';
		font-weight: 400;
		font-size: 24px;
        color: white;
		text-transform: uppercase;
	} 
    .nav-style{
          list-style-type: none !important;
          border-radius: 20px;
          background-color: #ffffff;
          padding: 10px 30px 10px 30px !important;
          border: solid 2px #92cdd5;
          margin-right: 10px;
          font-family: 'Raleway';
          font-size: 18px;
          letter-spacing: 1px;
        }

        .dropdown-item{
          padding: 0px 10px;
            font-size: 18px;
        }
        .dropdown-menu{
          padding: 15px;
          width: 250px;
          border-radius: 10px;
          box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
          background: #fff;
        }
    </style>
    </head>
    <body>

  <nav class="navbar navbar-fixed-top navbar-expand-lg navbar-light" style="background-image: linear-gradient( to left,#92cdd5, #ffffff, #ffffff);">
    <a class="navbar-brand" href="#">
        <img class="" src="imgs/SaharaLogo.png" alt="sahara-logo" style="width: 60%;">
    </a>
  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="indexmain.php">Home</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="aboutmain.php">About</a>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            Login
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="logincare.php">Caretaker</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logindoc.php">Doctor</a>
          </div>
        </li>
        <li class="nav-item dropdown nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Register
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registercare.php">Caretaker</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="registerdoc.php">Doctor</a>
            </div>
          </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link" href="helpmain.php">Contact Us</a>
          </li>
      </ul>
    </div>
  </nav>
  <!---------------------------------------------------------------------------------------------------------->
    <div class="container" style="margin-top: 50px;">
		<div class="row" style="margin-top: 130px;">
			<div class="col-md-offset-3 col-md-6" id="login-block">
				<div style="margin-bottom: 35px;">
					<h2 style="text-align: center;">Forgot Password</h2>
					<p style="text-align: center;">Provide your Email ID to reset your password</p>
				</div>
                <form id="frmForget" name="frmForget" method="post">
                <label class="label-text">Email ID:</label>
                <input type="email" name="user-email" placeholder="Enter a valid email" class="input-text" required>
                    <?php if(!empty($success_message)) { ?>
                    <div class="success_message label-text" style="text-align: center;color: green;"><?php echo $success_message ?>
                    <?php } ?>
                    <?php if(isset($error_message)) { ?> 
                    <div class="error_message label-text" style="text-align: center;color: red;"><?php echo $error_message; ?></div>
                    <?php } ?>
                    <input type="submit" value="submit" name="forget-password" id="forget-password">
                </form>
            </div>
        </div>
    </body>
</html>


<?php
require 'dbconfig/config.php';
//require './vendor/autoload.php';
ini_set( "display_errors", 0); 
  error_reporting( ~E_NOTICE );

   
  if(isset($_GET['patient_id']) && !empty($_GET['patient_id']))
  {
    $pid = $_GET['patient_id'];
    echo $pid;
   // $stmt_edit = $db->prepare('SELECT  pid,pname, gender,age, image,username,date FROM userspatient WHERE pid =:uid');
    //$stmt_edit->execute(array(':uid'=>$pid));
    //$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
    //extract($edit_row);
      
   //  $stmt_edit1 = $db->prepare('SELECT  id,dname,spec,date FROM visited_list WHERE id =:uid');
    // $stmt_edit1->execute(array(':uid'=>$id1));
    // $edit_row1 = $stmt_edit1->fetch(PDO::FETCH_ASSOC);
    // extract($edit_row1);
 
  }
?>
<html>
<head>
<title>Sahara | Caretaker Registration </title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.3.2/dist/chart.min.js"></script>
<style>
/*canvas {
  border: 1px dotted red;
}

.chart-container {
  position: relative;
  margin: auto;
  height: 80vh;
  width: 80vw;
}*/

</style>
</head>
<body>
<p>ECG</p>
<?php $pid = 1;?>
<canvas id="myChart"></canvas>
<script>
const api_url3 = 'https://ai4o7m4ofb.execute-api.us-east-2.amazonaws.com/dev3';//ecg
const xlabels = [];
const ytemps = [];

chartit();
async function chartit(){
await getAPI3();
setInterval(getAPI3,100);
const ctx = document.getElementById('myChart').getContext('2d');
//ctx.canvas.width = 200;
//ctx.canvas.height = 200;
const myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: xlabels,
        datasets: [{
            label: 'ECG',
            data: ytemps,
            backgroundColor:'rgba(255, 99, 132, 0.2)',
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 1
        }]
    },
    options: {
    maintainAspectRatio:false,
    //aspectRatio: 1,
    responsive:true
    //resizeDelay: 200
    }
    
});
}

console.log("hello");
//const api_url3 = 'https://ai4o7m4ofb.execute-api.us-east-2.amazonaws.com/dev3';//ecg
async function getAPI3(){
  var pid = <?php echo $pid ?>;
  console.log(pid);
    const response = await fetch(api_url3);
     data = await response.json();
    const{Patient_id,ts,ecg}=data;
   //var obj = JSON.parse(data);
   // console.log(data[0].ts);
   var pts = 0;

    for(i of data){
      if(i.Patient_id == pid && i.ts > pts)
     {  pts = i.ts;
        var demo = `${i.ecg}`;
        //var demo1 = `${i.ts}`;
        var myDate = new Date(i.ts);
        var date = myDate.toLocaleString()
        //document.getElementById('ecg').textContent = demo;
        ytemps.push(demo);
        //document.getElementById('date').textContent= date;
        xlabels.push(date);
        //document.getElementById('ts1').textContent = demo1;
        
        
     
    }
    console.log(data);
    //else
   // {
     // var demo1 = "no ID exists";
     // document.getElementById('ts').textContent = " ";
   // }
   
    
}
}
//getAPI3();
//setInterval(getAPI3,100);






   </script>

   </body>
   </html>

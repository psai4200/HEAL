<?php
require_once 'dbconfig/config.php';
require './vendor/autoload.php';
use \Firebase\JWT\JWT;
use GuzzleHttp\Client;
 
define('ZOOM_API_KEY', 'DpVgvQUtSKaCpN-E0Qcy4A');
define('ZOOM_SECRET_KEY', 'kjS5ksKhu9HUZya1JeUMgoB49olvp6uewVb9');

function getZoomAccessToken() {
    $key = ZOOM_SECRET_KEY;
    $payload = array(
        "iss" => ZOOM_API_KEY,
        'exp' => time() + 3600,
    );
    return JWT::encode($payload, $key);    
}

                     function createZoomMeeting() {
                        $client = new Client([
                            // Base URI is used with relative requests
                            'base_uri' => 'https://api.zoom.us',
                        ]);
                     
                        $response = $client->request('POST', '/v2/users/me/meetings', [
                            "headers" => [
                                "Authorization" => "Bearer " . getZoomAccessToken()
                            ],
                            'json' => [
                                "topic" => "Doctor Appointment",
                                "type" => 2,
                                "start_time" => "2021-01-30T20:30:00",
                                "duration" => "30", // 30 mins
                                "password" => "123456"
                            ],
                        ]);
                     
                        $data = json_decode($response->getBody());
                        // echo "Join URL: ". $data->join_url ."<a href='". $data->join_url ."'>Open URL</a>";
                        // echo "<br>";
                        // echo "Meeting Password: ". $data->password;
                        // echo "<br>";
                        echo "<a href='". $data->join_url ."' target='_blank'>Click to join now</a>";
                    }
                     
                    createZoomMeeting();
                     ?>
                    
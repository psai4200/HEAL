<?php
ob_start();
	session_start();
	require_once 'dbconfig/config.php';
  require_once 'vendor/autoload.php';
 
  use \Firebase\JWT\JWT;
  use GuzzleHttp\Client;
   
  
  if(isset($_SESSION['doctor_id']) && !empty($_SESSION['doctor_id']))
	 {
	 	$did = $_SESSION['doctor_id'];
	 	//$stmt_edit = $db->prepare('SELECT  did,dname, gender,age, image,username,date FROM userspatient WHERE pid =:uid');
    $stmt_edit = $db->prepare('SELECT did, dname, spec, gender, image, address, username, email, password, avai FROM usersdoc WHERE did =:uid');
	 	$stmt_edit->execute(array(':uid'=>$did));
	 	$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	 	extract($edit_row);
       
		//  $stmt_edit1 = $db->prepare('SELECT  id,dname,spec,date FROM visited_list WHERE id =:uid');
	 	// $stmt_edit1->execute(array(':uid'=>$id1));
	 	// $edit_row1 = $stmt_edit1->fetch(PDO::FETCH_ASSOC);
	 	// extract($edit_row1);
	
	 }
	 else
	 {
	 	header("Location: homepagedoc.php");
	 }
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<title>Sahara | Doctor's Homepage</title>
<style>
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("website.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  
}
.nav-style{
  list-style-type: none !important;
  
  background-color:#ffffff;
  padding: 10px 30px 10px 30px !important;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}


.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
.about-text{
    padding: 40px;
    padding-top: 0;
    font-size: 18px;
    text-align: justify;
    line-height: 1.5;
    font-family: 'Raleway';
} 
.heading{
	   text-align: center;
	   font-size: 24px;
	   font-family: 'Raleway';
	   text-transform: uppercase;
	   margin-top: -50px;
	   margin-bottom: 75px;
   }
   .heading1{
	   text-align: center;
	   font-size: 24px;
	   font-family: 'Raleway';
	   text-transform: uppercase;
	   margin-top: -50px;
	   margin-bottom: 60px;
   }
   .label-text{
      width: 50%;
      font-family: 'Raleway';
      font-size: 22px;
      font-weight: 400;
      text-align: left;
      border: black solid 1px;
      padding: 5px 20px;
      min-width: 160px;
      max-width: 160px;
      
   }
   .sidenav {
          background: #92cdd5;
          text-align: center;
          color: black;
          
          left: 0;
          width: 15%;
          min-height: calc(100vh - 0px);
          overflow: auto;
        }
        
        .sidenav a {
          /* padding: 20px 6px 25px 32px; */
          text-decoration: none;
          font-size: 20px;
          color: #000;
          display: block;
          text-align: left;
          margin-left: 20px;
          margin-top: 35px;
          font-family: 'Raleway';
        }
        
        .sidenav a:hover {
          color: #f1f1f1;
        }
        #logout_btn {
          margin-top: -220px;
          background-color: #c0392b;
          padding: 5px;
          color: white;
          width: 30%;
          text-align: center;
          font-size: 18px;
          font-weight: bold;
          margin-bottom: 20px;
          margin-left: 10px;
      }
      
    
      .myform{
      width: 50%;
      left: 80%;
      bottom: 75%;
      }
      .myformedit{
      width: 50%;
      position: absolute;
      left: 80%;
      bottom: 65%;
      }
      *{
    margin:0;
    padding:0;
    box-sizing: border-box;
    

  }
  .container{
      width 100%;
      height 100vh;
      display: flex;
      align-items:center;
      justify-content: center;

  }
  .profile-box{
      width: 60%;
      background: #ff574a;
      text-align: center;
      padding: 40px 90px;
      color: #fff;
      position: relative;
      border-radius: 20px;
  }
  .setting-icon{
      width: 25px;
      position: absolute;
      right: 40px;
      top: 40px;
  }
  .profile-pic{
      width: 150px;
      border-radius: 50%;
      background: #fff;
      padding : 6px;
      

  }
  .profile-box h2{
      font-size: 22px;
      margin-top: 20px;
      font-weight: 500;
      text-align: left;
      width: 100%;

  }
 
  @media only screen and (max-width: 1024px){
    html, body {
    margin: 0;
    padding: 0;
    
    height:100vh;
  width: 100vw;
  overflow-x: hidden;
  background-image: url("websiteresize.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  
}
.nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  margin-top: 0px;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}

  
  }
@media only screen and (max-width: 768px){
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("websiteipad.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
  .nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  margin-top: -40px;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}
.profile-box{
      width: 70%;
      background: #ff574a;
      text-align: center;
      padding: 40px 90px;
      color: #fff;
      position: relative;
      border-radius: 20px;
  }
  
  
}
  
      
</style>
</head>
<body>

    <nav class="navbar navbar-fixed-left navbar-expand-lg navbar-light" nav-style>
        <a class="navbar-brand" href="indexmain.php">
            <img src="SaharaLogo.png" alt="sahara-logo" style="width: 50%;">
        </a>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important; margin-left: 180px;">
          <a class="nav-link" href="homepagedoc.php" >Home</a>
        </li>
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="aboutmain.php" >About</a>
        </li>
        
        
        <li class="nav-item nav-style" style="padding: 0 25px; list-style-type: none !important;">
            <a class="nav-link" href="helpmain.php" >Contact Us</a>
          </li>
          <form class="nav-item nav-style" action="homepagedoc.php" method="post" style="margin-left:600px; margin-right:-50px; background-color: #ffffff; margin-top:-5px;">
				<button name="logout" type="submit" id="nav-link" class="btn btn-primary">Log Out</button>
			</form>
      </ul>
    </div>
      </nav>
       <!------------------------------------------------------------------------------------------------------->

<!------------------------------------------------------------------------------------------------------>
<div class="container">
    <div class="profile-box">
    <a href="editprofiledocnew.php">
        <img src="imgs/setting.png" class="setting-icon"  >
    </a>
        <img src="uploads/<?php echo $image; ?>" class="profile-pic" >
        <h2 >Doctor Name:  <?php echo "$dname"; ?></h2>
        <h2 >Username:  <?php echo "$username"; ?></h2>
        <h2 >Doctor ID : <?php echo "$did"; ?></h2>
        <h2 >Department: <?php echo "$spec"; ?></h2>
        <h2 >Address: <?php echo "$address"; ?></h2>
        
        

        
        

    </div>
</div>





 <!---------------------------------------------------------------------------------------------->

<!------------------------------------------------------------------------------------------------------>
<?php
			if(isset($_POST['logout']))
			{
				session_destroy();
				header('location:commonlogin.php');
			}
		?>
    
	

</div>
</div>

</body>
</html>
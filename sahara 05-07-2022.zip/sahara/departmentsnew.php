<?php
ini_set( "display_errors", 0); 
ob_start();
	require 'dbconfig/config.php';
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sahara | Departments</title>
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Montserrat+Alternates" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Noto+Sans+JP:300,400,500" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700" rel="stylesheet">

    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<style>
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("website.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  
}
.nav-style{
  list-style-type: none !important;
  
  background-color:#ffffff;
  padding: 10px 30px 10px 30px !important;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}


.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
.about-text{
    padding: 40px;
    padding-top: 0;
    font-size: 18px;
    text-align: justify;
    line-height: 1.5;
    font-family: 'Raleway';
} 
.heading{
	   text-align: center;
	   font-size: 24px;
	   font-family: 'Raleway';
	   text-transform: uppercase;
	   margin-top: -50px;
	   margin-bottom: 75px;
   }
   .heading1{
	   text-align: center;
	   font-size: 24px;
	   font-family: 'Raleway';
	   text-transform: uppercase;
	   margin-top: -50px;
	   margin-bottom: 60px;
   }
   .label-text{
      width: 50%;
      font-family: 'Raleway';
      font-size: 22px;
      font-weight: 400;
      text-align: left;
      border: black solid 1px;
      padding: 5px 20px;
      min-width: 160px;
      max-width: 160px;
      
   }
   
        #logout_btn {
          margin-top: -220px;
          background-color: #c0392b;
          padding: 5px;
          color: white;
          width: 30%;
          text-align: center;
          font-size: 18px;
          font-weight: bold;
          margin-bottom: 20px;
          margin-left: 10px;
      }
      
    
      .myform{
      width: 50%;
      left: 80%;
      bottom: 75%;
      }
      .myformedit{
      width: 50%;
      position: absolute;
      left: 80%;
      bottom: 65%;
      }
      *{
    margin:0;
    padding:0;
    box-sizing: border-box;
    

  }
  .container{
      width 100%;
      height 100vh;
      display: flex;
      align-items:center;
      justify-content: center;

  }
  

  .doc-card{
          margin-left: 40px;
          margin-right: 40px;
          margin-bottom: 30px;
          width: 300px;
          height: 400px;
          border-radius: 10px;
          box-shadow: 0 4px 4px 0 rgb(0 0 0 / 25%);
          background-color: #fcfbfb;
          text-align: center;

        }
        
        .dept-name{
          font-family: Raleway;
          font-size: 36px;
          font-weight: bold;
          text-align: center;
        }
        .view-doc-btn{
          padding: 10px;
          font-size: 14px;
          position: relative;
          left: 82px;
          border-radius: 5px;
          border: none;
          background-color: #92cdd5;
        }

        .dept-img{
            width: 100%;
            border-radius: 50%;
            margin-top: 30px;
        }

        .dept-info{
          text-align: center;
        }
        .page-header{
          font-family: 'Raleway';
          border-radius: 20px;
          font-size: 18px; 
          background-color:#a2d5dc; 
          text-align: center;
          padding-top: 5px;
        }
        .container-fluid button.view-doc-btn{
          display:block;
          text-align:center;
        }
       

  @media only screen and (max-width: 1024px){
    html, body {
    margin: 0;
    padding: 0;
    
    height:100vh;
  width: 100vw;
  overflow-x: hidden;
  background-image: url("websiteresize.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  
}
.nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  margin-top: 0px;
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}
.container-fluid{
  margin-left: -40px;
}

  
  }
@media only screen and (max-width: 768px){
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("websiteipad.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
  .nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
 
  
  margin-right: 0px;
  margin-left: 20px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}
.container-fluid{
  margin-left: 0px;
}

  
  
}
  
      
</style>
</head>
<body>

    <nav class="navbar navbar-fixed-left navbar-expand-lg navbar-light" nav-style>
        <a class="navbar-brand" href="indexmain.php">
            <img src="SaharaLogo.png" alt="sahara-logo" style="width: 50%;">
        </a>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
        
        <li class="nav-item active nav-style"  style="padding: 0 25px; list-style-type: none !important;">
          <a class="nav-link" href="homepagecarenew.php" style="margin-left:10px;" >Home</a>
          <a  class="nav-link" href="doctor-pagenew.php" style="margin-left:10px;" >Doctors</a>
          
          <a class="nav-link" href="homepagepatientnew.php" style="margin-left:10px;">Patients</a>
          <a class="nav-link" href="profilecare.php" style="margin-left:10px;">profile</a>
          
        </li>
        
        
        
        
          

        
      <form class="nav-item nav-style" action="homepagecarenew.php" method="post" style="margin-left:400px; margin-right:-50px; background-color: #ffffff; margin-top:-5px;">
				<button name="logout" type="submit" id="nav-link" class="btn btn-primary">Log Out</button>
			</form>
        
      </ul>
    </div>
      </nav>
       <!------------------------------------------------------------------------------------------------------->

<!------------------------------------------------------------------------------------------------------>
<div class="container-fluid">
<div class="row" style=" margin-top: 60px;">
<h1 class="heading">&nbsp; Departments</h1>
</div>
    <div class="container-fluid">
      <div class="row" style="margin-left: 200px;">
        <div class="col-md-4 doc-card">
          <img src="img/dept1.jpeg" class="dept-img" alt="dept-img">
          <h2 class="dept-name">General Medicine</h2>
          <p class="dept-info">Dept Info</p>
          <button class="view-doc-btn"><a href="generalmed.php">View Doctors</a></button>
        </div>
        <div class="col-md-4 doc-card">
          <img src="img/dept2.png" class="dept-img" alt="dept-img" style="width: 73%;margin-left: 40px;">
          <h2 class="dept-name">Pregnancy</h2>
          <p class="dept-info">Dept Info</p>
          <button class="view-doc-btn"><a href="pregnancy.php">View Doctors</a></button>
        </div>
        <div class="col-md-4 doc-card">
          <img src="img/dept3.jpeg" class="dept-img" alt="dept-img" style="width: 90%;margin-left: 12px;">
          <h2 class="dept-name">Surgery</h2>
          <p class="dept-info">Dept Info</p>
          <button class="view-doc-btn"><a href="surgery.php">View Doctors</a></button>
        </div>
      </div>
      <div class="row" style="margin-top: 20px;margin-left: 200px;">
        <div class="col-md-4 doc-card">
          <img src="img/dept4.jpeg" class="dept-img" alt="dept-img" style="width: 90%;margin-left: 12px;">
          <h2 class="dept-name">Neurology</h2>
          <p class="dept-info">Dept Info</p>
          <button class="view-doc-btn"><a href="neurology.php">View Doctors</a></button>
        </div>
        <div class="col-md-4 doc-card">
          <img src="img/dept5.jpeg" class="dept-img" alt="dept-img" style="margin-top: 60px;">
          <h2 class="dept-name">Pediatrics</h2>
          <p class="dept-info">Dept Info</p>
          <button class="view-doc-btn"><a href="pediatrics.php">View Doctors</a></button>
        </div>
        <div class="col-md-4 doc-card">
          <img src="img/dept6.jpeg" class="dept-img" alt="dept-img" style="margin-top: 70px;">
          <h2 class="dept-name">Psychology</h2>
          <p class="dept-info">Dept Info</p>
          <button class="view-doc-btn"><a href="psychology.php">View Doctors</a></button>
        </div>
      </div>
    </div>
  </div> 




 <!---------------------------------------------------------------------------------------------->

<!------------------------------------------------------------------------------------------------------>
<?php
			if(isset($_POST['logout']))
			{
				session_destroy();
				header('location:commonlogin.php');
			}
		?>
    
	

</div>
</div>

</body>
</html>
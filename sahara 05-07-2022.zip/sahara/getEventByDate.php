<?php
   require  'dbconfig/config.php';
    $eventDate = $_POST['eventDate'];
    $query="select * from event where date = '" . $eventDate . "'";
    $result = $con->query($query) or die($con->error);
    $eventResult = array();
    while ($row =$result->fetch_assoc()) {
        $eventResult[] = $row;
    }
    echo json_encode($eventResult);
 ?>
 
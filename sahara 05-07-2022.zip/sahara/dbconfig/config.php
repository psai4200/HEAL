
<?php
$servername = "finalyear.ctapwniovwll.us-east-2.rds.amazonaws.com";//endpoint
$username = "admin";//db user name
$password = "finalyear";//db password
$dbname = "finalyear"; // database user

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);


//$con = mysqli_connect($servername,$username,$password,$dbname) or die("Unable to connect");
//mysqli_select_db($con,'finalyear');
//if($con)echo "hello from rds";


?> 
<?php
$db = new PDO('mysql:host=finalyear.ctapwniovwll.us-east-2.rds.amazonaws.com;dbname=finalyear; charset=utf8mb4','admin','finalyear',
        array(PDO::ATTR_EMULATE_PREPARES => false, 
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
<style>
.nav-style{
  list-style-type: none !important;
  border-radius: 20px;
  background-color: #ffffff;
  padding: 10px 30px 10px 30px !important;
  border: solid 2px #92cdd5;
  margin-right: 10px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}

.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
</style>
</head>
<body>
    <nav class="navbar navbar-fixed-top navbar-expand-lg navbar-light" style="background-image: linear-gradient( to left,#92cdd5, #ffffff, #ffffff);"  nav-style>
        <a class="navbar-brand" href="#">
            <img src="SaharaLogo.png" alt="sahara-logo" style="width: 60%;">
        </a>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto" style="float: right; padding: 25px;">
            <li class="nav-item active  nav-style"  style="padding: 0 25px; list-style-type: none !important;">
              <a class="nav-link" href="indexmain.php">Home</a>
            </li>
            <li class="nav-item  nav-style" style="padding: 0 25px; list-style-type: none !important;">
              <a class="nav-link" href="aboutmain.php">About</a>
            </li>
            <li class="nav-item dropdown  nav-style" style="padding: 0 25px; list-style-type: none !important;">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Login
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="logincare.php">Caretaker</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="logindoc.php">Doctor</a>
              </div>
            </li>
            <li class="nav-item dropdown  nav-style" style="padding: 0 25px; list-style-type: none !important;">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Register
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="registercare.php">Caretaker</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="registerdoc.php">Doctor</a>
                </div>
              </li>
            <li class="nav-item  nav-style" style="padding: 0 25px; list-style-type: none !important;">
                <a class="nav-link" href="helpmain.php">Contact Us</a>
              </li>
          </ul>
        </div>
      </nav>
</body>
</html>
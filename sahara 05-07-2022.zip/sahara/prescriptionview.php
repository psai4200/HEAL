<?php
ini_set( "display_errors", 0); 
	error_reporting( ~E_NOTICE );
	require_once 'dbconfig/config.php';
  require './vendor/autoload.php';
  use Aws\AwsClient;
  
	 if(isset($_GET['pv_id']) && !empty($_GET['pv_id']))
	 {
	 	$id = $_GET['pv_id'];
	 	$stmt_edit = $db->prepare('SELECT * FROM visited_list WHERE id =:uid');
	 	$stmt_edit->execute(array(':uid'=>$id));
	 	$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	 	extract($edit_row);
       
		//  $stmt_edit1 = $db->prepare('SELECT  id,dname,spec,date FROM visited_list WHERE id =:uid');
	 	// $stmt_edit1->execute(array(':uid'=>$id1));
	 	// $edit_row1 = $stmt_edit1->fetch(PDO::FETCH_ASSOC);
	 	// extract($edit_row1);
	
	 }
	 else
	 {
	 	header("Location: homepagecare.php");
	 }
     
?>

<!DOCTYPE html>
<html>
<head>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sahara | Home Page</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat+Alternates" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Noto+Sans+JP:300,400,500" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700" rel="stylesheet">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    


<script type="text/javascript">

    function PreviewImage() {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("image").files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("uploadPreview").src = oFREvent.target.result;
        };
    };

</script>
<style>


  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("website.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  }
  
  .nav-style{
  list-style-type: none !important;
  
  background-color:#ffffff;
  padding: 10px 30px 10px 30px !important;
  
  margin-right: 0px;
  margin-left:1400px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}

.dropdown-item{
  padding: 0px 10px;
    font-size: 18px;
}
.dropdown-menu{
  padding: 15px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 2px 21px 6px rgb(147 147 147 / 8%);
  background: #fff;
}
.heromodule{
    /* background: linear-gradient(180deg, rgba(181,237,251,1) 0%, rgba(251,255,252,1) 39%, rgba(255,249,194,1) 100%); */
    position: absolute;
    margin-left: 350px;
}
.aligntext{
    text-align: center;
}
.hero-text{
  font-family: 'Raleway';
  color: #2c5e8a;
  font-weight: 600;
  text-transform: capitalize;
  padding: 20px 0 0;
  font-size: 55px;
  text-align: left;
  line-height: 1.2;
}
.hero-subtext{
  font-family: 'Noto Sans JP', sans-serif;
  font-size: 20px;
  text-align: left;
  color: #6a6a77;
}
.visit-text{
  font-family: 'Noto Sans JP', sans-serif;
  font-size: 22px;
  text-align: left;
  color: #6a6a77;
  padding-top: 10px;
}
.visit-head{
  font-size: 40px;
  font-weight: 500;
  color: #3c6890;
}
.register-btn{
  font-size: 26px;
  padding: 10px;
  margin: 10px 0;
  margin-right: 5px;
  background-color: #ffce1e;
  border-color: #ffce1e;
  font-weight: 600;
  width: 30%;
}
  
  
@media only screen and (max-width: 1024px){
    html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  width: 100%;
  overflow-x: hidden;
  background-image: url("websiteresize.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
  
}
.heromodule{
 margin-left: 200px;
}
.nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  
  
  margin-right: 50px;
  margin-left: 900px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}


  
  }
@media only screen and (max-width: 768px){
  html, body {
    margin: 0;
    padding: 0;
    
    height:100%;
  max-width: 100%;
  overflow-x: hidden;
  background-image: url("websiteipad.jpg");
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.heromodule{
 margin-left: 10px;
 margin-top: 140px;
 
 align: center;
}
  .nav-style{
  list-style-type: none !important;
  
  background-color:rgba(0,0,0,0);
  padding: 10px 30px 10px 30px !important;
  
  
  margin-right: 50px;
  margin-left: 625px;
  font-family: 'Raleway';
  font-size: 18px;
  letter-spacing: 1px;
}
.navbar-brand{
 
}
}

      
</style>
</head>
<body>

    
  <nav  nav-style>
        <a class="navbar-brand" href="indexmain1.php">
            <img src="SaharaLogo.png" alt="sahara-logo" style="width: 50%;">
        </a>
      
        
        
        <li class="nav-item  nav-style"  style="padding: 0 25px; list-style-type: none !important; width:10%;  margin-top:15px;">
          
          <a class="btn btn-primary" href="commonlogin.php " style="margin-left:10px; ">Login</a>
          
          
        </li>

        <div class="container">
        <img src="<?php echo $image; ?>" class="profile-pic" >
        
        </div>

        
       <!------------------------------------------------------------------------------------------------------->

<!------------------------------------------------------------------------------------------------------>

      <!-- ---------------------------------------- -->
      
</body>
</html>